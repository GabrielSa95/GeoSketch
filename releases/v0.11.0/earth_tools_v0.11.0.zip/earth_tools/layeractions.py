# -*- coding: utf-8 -*-
"""Itens do plugin no menu de botao direito do painel Camadas.

NAO usamos QgsLayerTreeView.setMenuProvider(): esse metodo ASSUME A POSSE do
provedor e DELETA o anterior. Guardar o provedor original e chamar
createContextMenu() nele acessa memoria liberada e derruba o QGIS inteiro.

Usamos addCustomActionForLayerType / addCustomActionForLayer, que e a API
feita para isso: o QGIS continua dono do menu e apenas encaixa nossas acoes.
"""

import os
import subprocess
import sys
import tempfile
import webbrowser

from qgis.core import QgsLayerTree, QgsProject, QgsVectorFileWriter
from qgis.PyQt.QtCore import QEvent, QObject, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QAction,
    QFileDialog,
    QInputDialog,
    QMessageBox,
)

from . import kml_bridge, kml_io, places_model, storage, utils

PLUGIN_DIR = os.path.dirname(__file__)


def _vector_type():
    """O enum de tipo de camada mudou de lugar entre versoes."""
    try:
        from qgis.core import Qgis

        return Qgis.LayerType.Vector
    except Exception:
        from qgis.core import QgsMapLayerType

        return QgsMapLayerType.VectorLayer


def icon(name):
    return QIcon(os.path.join(PLUGIN_DIR, "icons", name))


class DeleteKeyFilter(QObject):
    """Captura a tecla Delete no painel Camadas.

    Filtro de evento em vez de atalho global de propósito: precisamos deixar o
    Delete passar quando a árvore está em modo de renomear, senão o usuário não
    consegue apagar uma letra do nome sem apagar a camada inteira.
    """

    def __init__(self, view, handler):
        super(DeleteKeyFilter, self).__init__(view)
        self.view = view
        self.handler = handler

    def eventFilter(self, obj, event):
        try:
            if event.type() != QEvent.KeyPress:
                return False
            if event.key() not in (Qt.Key_Delete, Qt.Key_Backspace):
                return False
            if self.view.state() == QAbstractItemView.EditingState:
                return False  # está renomeando: a tecla é do campo de texto
            self.handler()
            return True
        except Exception:
            return False


class LayerActions(object):
    def __init__(self, iface, plugin):
        self.iface = iface
        self.plugin = plugin
        self.actions = []
        self.place_actions = []  # so aparecem nos lugares criados pelo plugin
        self._delete_filter = None

    # ---------------------------------------------------------- instalacao
    def install(self):
        window = self.iface.mainWindow()
        vector = _vector_type()

        def make(text, ico, callback, menu, all_layers):
            action = QAction(icon(ico) if ico else QIcon(), text, window)
            action.triggered.connect(callback)
            self.iface.addCustomActionForLayerType(action, menu, vector, all_layers)
            self.actions.append(action)
            if not all_layers:
                self.place_actions.append(action)
            return action

        # Aparecem apenas nas camadas registradas (os lugares do plugin).
        make("Editar...", "vertex.svg", self._edit_points, "", False)
        make("Ir para", "goto.svg", self._goto_layer, "", False)
        make("Mover para pasta...", "folder.svg", self._move_to_folder, "", False)
        make("Excluir", None, self.delete_selected, "", False)
        make("Salvar lugar como...", None, self._save_as, "", False)
        make("Enviar por e-mail...", None, self._email, "", False)

        # Submenu "Adicionar", disponivel em qualquer camada vetorial.
        make("Pasta", "folder.svg", self._new_group, "Adicionar", True)
        make("Modelo de propriedade rural", "folder.svg",
             self._new_property_template, "Adicionar", True)
        make("Marcador de local", "placemark.svg",
             lambda: self.plugin.open_feature("point", self._current_group()),
             "Adicionar", True)
        make("Caminho", "path.svg",
             lambda: self.plugin.open_feature("line", self._current_group()),
             "Adicionar", True)
        make("Poligono", "polygon.svg",
             lambda: self.plugin.open_feature("polygon", self._current_group()),
             "Adicionar", True)
        make("Sobreposicao de imagem", None, self._image_overlay, "Adicionar", True)

        # Registra o que ja existe e o que vier depois.
        for layer in QgsProject.instance().mapLayers().values():
            self.register_layer(layer)
        try:
            QgsProject.instance().layersAdded.connect(self._layers_added)
        except Exception:
            pass

        try:
            view = self.iface.layerTreeView()
            self._delete_filter = DeleteKeyFilter(view, self.delete_selected)
            view.installEventFilter(self._delete_filter)
        except Exception:
            self._delete_filter = None

    def uninstall(self):
        if getattr(self, "_delete_filter", None) is not None:
            try:
                self.iface.layerTreeView().removeEventFilter(self._delete_filter)
            except Exception:
                pass
            self._delete_filter = None
        try:
            QgsProject.instance().layersAdded.disconnect(self._layers_added)
        except Exception:
            pass
        for action in self.actions:
            try:
                self.iface.removeCustomActionForLayerType(action)
            except Exception:
                pass
        self.actions = []
        self.place_actions = []

    def _layers_added(self, layers):
        for layer in layers:
            self.register_layer(layer)

    def register_layer(self, layer):
        """Libera as acoes de lugar naquela camada especifica."""
        if not storage.is_place_layer(layer):
            return
        for action in self.place_actions:
            try:
                self.iface.addCustomActionForLayer(action, layer)
            except Exception:
                pass

    # --------------------------------------------------------------- apoio
    def _current_layer(self):
        try:
            return self.iface.layerTreeView().currentLayer()
        except Exception:
            return None

    def _current_group(self):
        try:
            node = self.iface.layerTreeView().currentNode()
            if node is not None and hasattr(node, "addGroup"):
                return node
            group = self.iface.layerTreeView().currentGroupNode()
            root = QgsProject.instance().layerTreeRoot()
            return group if group is not None and group != root else None
        except Exception:
            return None

    # --------------------------------------------------------------- acoes
    def _edit_points(self):
        layer = self._current_layer()
        if layer is None:
            return
        self.plugin.edit_place(layer)

    def _goto_layer(self):
        layer = self._current_layer()
        if layer is None:
            return
        utils.zoom_to_layer(self.iface, layer)

    def delete_selected(self):
        """Confirma e exclui o que estiver selecionado no painel Camadas."""
        try:
            view = self.iface.layerTreeView()
            nodes = view.selectedNodes(True)
        except Exception:
            return
        if not nodes:
            return

        places, others, groups = _collect(nodes)
        if not places and not others and not groups:
            return

        texto = _confirm_text(places, others, groups)
        box = QMessageBox(self.iface.mainWindow())
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("Confirmar exclusao")
        box.setText("Deseja mesmo excluir?")
        box.setInformativeText(texto)
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setDefaultButton(QMessageBox.No)
        box.button(QMessageBox.Yes).setText("Excluir")
        box.button(QMessageBox.No).setText("Cancelar")
        if box.exec_() != QMessageBox.Yes:
            return

        failed_names = []
        for layer in places:
            nome = layer.name()
            # Captura a chave ANTES de apagar: depois de delete_place() o
            # objeto Python pode nao ser mais seguro de consultar.
            tabela = storage.table_name(layer)
            try:
                removed = storage.delete_place(layer)
            except Exception:
                removed = False
            if not removed:
                failed_names.append(nome)
            try:
                places_model.remove_place_membership(tabela)
            except Exception as exc:
                utils.log(
                    "Falha ao limpar organizacao do lugar '{}': {}".format(nome, exc),
                    "warning",
                )
        for layer in others:
            try:
                QgsProject.instance().removeMapLayer(layer.id())
            except Exception:
                pass
        for node in groups:
            # Captura os ids canonicos da pasta E de qualquer subpasta
            # aninhada ANTES de remover o no - apagar o grupo apaga a
            # subarvore inteira, e cada subpasta rastreada precisa do
            # proprio registro limpo, senao fica orfao no GeoPackage.
            folder_ids = []
            top_fid = places_model.resolve_group_folder_id(node)
            if top_fid:
                folder_ids.append(top_fid)
            folder_ids.extend(_nested_folder_ids(node))
            try:
                parent = node.parent()
                if parent is not None:
                    parent.removeChildNode(node)
            except Exception:
                pass
            for fid in folder_ids:
                try:
                    places_model.delete_folder_record(fid)
                except Exception as exc:
                    utils.log(
                        "Falha ao limpar registro da pasta '{}': {}".format(fid, exc),
                        "warning",
                    )

        total = len(places) + len(others) + len(groups)
        self.iface.messageBar().pushInfo(
            "Ferramentas Terra", "{} item(ns) excluido(s).".format(total)
        )
        if failed_names:
            # Saiu do painel, mas a tabela pode ter ficado orfa no GeoPackage
            # (ex.: arquivo bloqueado por outro programa). Avisa quais, para
            # nao dar a falsa impressao de exclusao completa. storage.delete_place
            # ja registrou o detalhe tecnico de cada uma; aqui so o resumo.
            utils.log(
                "Exclusao incompleta no GeoPackage para: {}".format(", ".join(failed_names)),
                "warning",
            )
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Ferramentas Terra",
                "{} saiu do painel, mas a tabela não pôde ser apagada do "
                "arquivo:\n{}\n\nArquivo: {}".format(
                    "Estes itens" if len(failed_names) > 1 else "Este item",
                    ", ".join(failed_names),
                    storage.gpkg_path(),
                ),
            )

    def _new_group(self):
        name, ok = QInputDialog.getText(
            self.iface.mainWindow(), "Nova pasta", "Nome da pasta:", text="Nova pasta"
        )
        if not ok or not name.strip():
            return
        pai_id = places_model.resolve_group_folder_id(self._current_group())
        try:
            places_model.create_folder(name.strip(), pai_id=pai_id)
            places_model.rebuild_layer_tree(self.iface)
        except Exception as exc:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Ferramentas Terra",
                "Não foi possível criar a pasta:\n{}".format(exc),
            )

    def _new_property_template(self):
        name, ok = QInputDialog.getText(
            self.iface.mainWindow(),
            "Modelo de propriedade rural",
            "Nome do imóvel:",
            text="Imóvel sem título",
        )
        if not ok or not name.strip():
            return
        pai_id = places_model.resolve_group_folder_id(self._current_group())
        try:
            places_model.create_property_template(name.strip(), pai_id=pai_id)
            places_model.rebuild_layer_tree(self.iface)
        except Exception as exc:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "Ferramentas Terra",
                "Não foi possível criar o modelo:\n{}".format(exc),
            )

    def _move_to_folder(self):
        layer = self._current_layer()
        if layer is None:
            return
        from .dlg_move_folder import MoveFolderDialog

        dialog = MoveFolderDialog(self.iface, layer, self.iface.mainWindow())
        dialog.exec_()

    def _export(self, layer, path, driver):
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = driver
        options.fileEncoding = "UTF-8"
        context = QgsProject.instance().transformContext()
        if hasattr(QgsVectorFileWriter, "writeAsVectorFormatV3"):
            result = QgsVectorFileWriter.writeAsVectorFormatV3(layer, path, context, options)
        else:
            result = QgsVectorFileWriter.writeAsVectorFormatV2(layer, path, context, options)
        return result[0] == QgsVectorFileWriter.NoError, result[1]

    def _export_place_kml(self, layer, path, as_kmz):
        """KML/KMZ de UM lugar, pelo escritor proprio (kml_io), nao pelo
        driver generico do GDAL - preserva nome/descricao/estilo de forma
        mais fiel (Fase D). Usado tanto por 'Salvar lugar como...' quanto
        por 'Enviar por e-mail...', para nao ter dois geradores de KML
        divergentes."""
        tree = kml_bridge.export_layer(layer)
        if tree is None:
            return False, "lugar sem feição para exportar"
        try:
            data = kml_io.build_kmz(tree) if as_kmz else kml_io.build_kml(tree).encode("utf-8")
            with open(path, "wb") as f:
                f.write(data)
        except Exception as exc:
            return False, str(exc)
        return True, None

    def _save_as(self):
        layer = self._current_layer()
        if layer is None:
            return
        path, selected = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            "Salvar lugar como",
            layer.name(),
            "Google Earth (*.kml);;Google Earth compactado (*.kmz);;"
            "GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson)",
        )
        if not path:
            return
        low = selected.lower()
        if "kmz" in low:
            ok, message = self._export_place_kml(layer, path, as_kmz=True)
        elif "kml" in low:
            ok, message = self._export_place_kml(layer, path, as_kmz=False)
        else:
            driver = "GPKG" if "gpkg" in low else "ESRI Shapefile" if "shp" in low else "GeoJSON"
            ok, message = self._export(layer, path, driver)
        if ok:
            self.iface.messageBar().pushSuccess("Ferramentas Terra", "Salvo em " + path)
        else:
            QMessageBox.warning(self.iface.mainWindow(), "Salvar lugar como", message)

    def _email(self):
        layer = self._current_layer()
        if layer is None:
            return
        folder = tempfile.gettempdir()
        path = os.path.join(folder, storage.slug(layer.name()) + ".kml")
        ok, message = self._export_place_kml(layer, path, as_kmz=False)
        if not ok:
            QMessageBox.warning(self.iface.mainWindow(), "Enviar por e-mail", message)
            return
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception:
            pass
        webbrowser.open(
            "mailto:?subject={}&body=Segue%20o%20arquivo%20{}".format(
                layer.name().replace(" ", "%20"), os.path.basename(path)
            )
        )
        self.iface.messageBar().pushInfo(
            "Ferramentas Terra", "Arquivo gerado em {}. Anexe-o ao e-mail.".format(path)
        )

    def _image_overlay(self):
        path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Sobreposicao de imagem",
            "",
            "Imagens (*.tif *.tiff *.jpg *.jpeg *.png *.ecw *.sid)",
        )
        if not path:
            return
        layer = self.iface.addRasterLayer(path, os.path.basename(path))
        if layer is None or not layer.isValid():
            answer = QMessageBox.question(
                self.iface.mainWindow(),
                "Sobreposicao de imagem",
                "A imagem nao tem coordenadas. Abrir o Georreferenciador?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if answer == QMessageBox.Yes:
                QMessageBox.information(
                    self.iface.mainWindow(),
                    "Sobreposicao de imagem",
                    "Abra em Raster > Georreferenciador.",
                )


# --------------------------------------------------------------------------
# Exclusao com confirmacao (tecla Delete ou item do menu)
# --------------------------------------------------------------------------
def _collect(nodes):
    """Separa o que foi selecionado em lugares, camadas comuns e pastas.

    Precisa entrar nas pastas: apagar uma pasta tem que apagar os lugares que
    estao dentro dela, senao ficariam tabelas orfas no GeoPackage.
    """
    places, others, groups = [], [], []
    seen = set()

    def add_layer(layer):
        if layer is None or layer.id() in seen:
            return
        seen.add(layer.id())
        if storage.is_place_layer(layer):
            places.append(layer)
        else:
            others.append(layer)

    for node in nodes:
        try:
            if QgsLayerTree.isGroup(node):
                groups.append(node)
                for child in node.findLayers():
                    add_layer(child.layer())
            elif QgsLayerTree.isLayer(node):
                add_layer(node.layer())
        except Exception:
            continue
    return places, others, groups


def _nested_folder_ids(node):
    """Ids canonicos de pasta de qualquer subgrupo dentro de node, em
    qualquer profundidade - usado para limpar o registro das subpastas
    quando o grupo-mae e apagado de uma vez."""
    ids = []
    for child in node.children():
        if QgsLayerTree.isGroup(child):
            fid = places_model.resolve_group_folder_id(child)
            if fid:
                ids.append(fid)
            ids.extend(_nested_folder_ids(child))
    return ids


def _confirm_text(places, others, groups):
    linhas = []
    if places:
        nomes = ", ".join(l.name() for l in places[:4])
        if len(places) > 4:
            nomes += " e mais {}".format(len(places) - 4)
        linhas.append(
            "{} lugar(es) serao APAGADOS do arquivo Meus Lugares, sem volta:\n{}".format(
                len(places), nomes
            )
        )
    if others:
        linhas.append(
            "{} camada(s) serao removidas do projeto. Os arquivos de origem "
            "delas NAO serao apagados.".format(len(others))
        )
    if groups:
        linhas.append("{} pasta(s) serao removidas.".format(len(groups)))
    return "\n\n".join(linhas)
