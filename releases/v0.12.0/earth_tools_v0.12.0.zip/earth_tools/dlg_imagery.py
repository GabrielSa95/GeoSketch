# -*- coding: utf-8 -*-
"""Janela "Imagens de satélite" (Fase E): busca Sentinel-2/Landsat por área
e período, mostra os metadados disponíveis, carrega a cena escolhida no
mapa, e permite alternar entre duas datas para comparação visual simples.

Não toca no GeoPackage "Meus Lugares" nem em nenhuma geometria - só cria
camadas raster novas no projeto. Funciona de forma assíncrona (não
congela o canvas); se a internet estiver indisponível, só esta janela é
afetada - desenho, edição, régua e lugares salvos continuam funcionando.
"""

import datetime as _dt

from qgis.core import QgsPointXY, QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)

from . import imagery_bridge, stac_client, storage, utils

PROVIDER_ITEMS = [("sentinel2", "Sentinel-2 (L2A)"), ("landsat", "Landsat (Coleção 2 Nível 2)")]


class ImageryDialog(QDialog):
    def __init__(self, iface, parent=None):
        super(ImageryDialog, self).__init__(parent)
        self.iface = iface
        self.scenes = []
        self.request = None
        self.slot_layers = {"A": None, "B": None}

        self.setWindowTitle("Ferramentas Terra - Imagens de satélite")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setModal(False)
        self.setMinimumSize(480, 560)

        layout = QVBoxLayout(self)

        note = QLabel(
            "Fonte: Earth Search (Element84), catálogo público Sentinel-2/Landsat, sem "
            "necessidade de cadastro. Datas diferentes podem ter resolução, cobertura de "
            "nuvens e condições de iluminação diferentes - não são uma comparação "
            "perfeitamente equivalente."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #555; font-style: italic;")
        layout.addWidget(note)

        form = QFormLayout()
        self.area_combo = QComboBox()
        self.area_combo.addItems(["Extensão atual do mapa", "Feição selecionada"])
        form.addRow("Área de interesse:", self.area_combo)

        self.provider_combo = QComboBox()
        for key, label in PROVIDER_ITEMS:
            self.provider_combo.addItem(label, key)
        form.addRow("Fonte:", self.provider_combo)

        dates_row = QHBoxLayout()
        self.start_edit = QDateEdit(calendarPopup=True)
        self.start_edit.setDate(_dt.date.today() - _dt.timedelta(days=90))
        self.end_edit = QDateEdit(calendarPopup=True)
        self.end_edit.setDate(_dt.date.today())
        dates_row.addWidget(self.start_edit)
        dates_row.addWidget(QLabel("até"))
        dates_row.addWidget(self.end_edit)
        form.addRow("Período:", dates_row)
        layout.addLayout(form)

        search_row = QHBoxLayout()
        self.btn_search = QPushButton("Buscar")
        self.btn_cancel = QPushButton("Cancelar consulta")
        self.btn_cancel.setEnabled(False)
        search_row.addWidget(self.btn_search)
        search_row.addWidget(self.btn_cancel)
        layout.addLayout(search_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)  # indeterminado - nao sabemos a duracao da consulta
        self.progress.hide()
        layout.addWidget(self.progress)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        self.meta_label = QLabel("Selecione uma aquisição na lista para ver os detalhes.")
        self.meta_label.setWordWrap(True)
        layout.addWidget(self.meta_label)

        load_row = QHBoxLayout()
        self.btn_load = QPushButton("Carregar no mapa")
        self.btn_load.setEnabled(False)
        load_row.addWidget(self.btn_load)
        layout.addLayout(load_row)

        compare_box = QGroupBox("Comparar duas datas")
        compare_layout = QVBoxLayout(compare_box)
        self.compare_label = QLabel(
            "Carregue uma aquisição em \"Anterior\" e outra em \"Posterior\"; use as caixas "
            "para alternar qual fica visível, sem perder o enquadramento do mapa. Para um "
            "slider de comparação lado a lado, use a ferramenta nativa do QGIS "
            "Ver > Painéis > Mapa comparativo (Map Swipe Tool)."
        )
        self.compare_label.setWordWrap(True)
        self.compare_label.setStyleSheet("color: #555; font-style: italic;")
        compare_layout.addWidget(self.compare_label)

        self.slot_checks = {}
        self.slot_status = {}
        for slot, title in (("A", "Anterior"), ("B", "Posterior")):
            row = QHBoxLayout()
            check = QCheckBox("Mostrar " + title)
            check.setEnabled(False)
            check.toggled.connect(lambda checked, s=slot: self._toggle_slot(s, checked))
            status = QLabel("(nenhuma carregada)")
            btn = QPushButton("Carregar aqui")
            btn.clicked.connect(lambda _checked, s=slot: self._load_into_slot(s))
            row.addWidget(btn)
            row.addWidget(check)
            row.addWidget(status)
            row.addStretch()
            compare_layout.addLayout(row)
            self.slot_checks[slot] = check
            self.slot_status[slot] = status
        layout.addWidget(compare_box)

        cache_row = QHBoxLayout()
        self.cache_label = QLabel()
        self.btn_clear_cache = QPushButton("Limpar cache de busca")
        cache_row.addWidget(self.cache_label)
        cache_row.addStretch()
        cache_row.addWidget(self.btn_clear_cache)
        layout.addLayout(cache_row)
        self._refresh_cache_label()

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.close)
        layout.addWidget(buttons)

        self.btn_search.clicked.connect(self._do_search)
        self.btn_cancel.clicked.connect(self._do_cancel)
        self.list_widget.currentRowChanged.connect(self._show_metadata)
        self.btn_load.clicked.connect(self._load_selected)
        self.btn_clear_cache.clicked.connect(self._do_clear_cache)

    # -------------------------------------------------------------- area
    def _current_bbox(self):
        """(min_lon, min_lat, max_lon, max_lat) em WGS84, ou (None, mensagem)."""
        canvas = self.iface.mapCanvas()
        if self.area_combo.currentIndex() == 0:
            extent = canvas.extent()
            crs = canvas.mapSettings().destinationCrs()
            p1 = utils.to_wgs84(QgsPointXY(extent.xMinimum(), extent.yMinimum()), crs)
            p2 = utils.to_wgs84(QgsPointXY(extent.xMaximum(), extent.yMaximum()), crs)
        else:
            layer = None
            try:
                layer = self.iface.layerTreeView().currentLayer()
            except Exception:
                pass
            if layer is None or not storage.is_place_layer(layer):
                return None, "Selecione um lugar criado pelo plugin no painel Camadas primeiro."
            extent = layer.extent()  # lugares ja estao em EPSG:4326
            p1 = QgsPointXY(extent.xMinimum(), extent.yMinimum())
            p2 = QgsPointXY(extent.xMaximum(), extent.yMaximum())

        min_lon, max_lon = min(p1.x(), p2.x()), max(p1.x(), p2.x())
        min_lat, max_lat = min(p1.y(), p2.y()), max(p1.y(), p2.y())
        if max_lon - min_lon < 0.001 or max_lat - min_lat < 0.001:
            # feicao pontual ou extensao quase nula: aplica uma folga para
            # a busca ter uma area de verdade para consultar.
            pad = 0.01
            cx, cy = (min_lon + max_lon) / 2.0, (min_lat + max_lat) / 2.0
            min_lon, max_lon = cx - pad, cx + pad
            min_lat, max_lat = cy - pad, cy + pad
        return (min_lon, min_lat, max_lon, max_lat), None

    # ------------------------------------------------------------- busca
    def _do_search(self):
        bbox, error = self._current_bbox()
        if bbox is None:
            QMessageBox.information(self, "Ferramentas Terra", error)
            return

        provider_key = self.provider_combo.currentData()
        start = self.start_edit.date().toPyDate()
        end = self.end_edit.date().toPyDate()
        try:
            stac_client.validate_date_range(start, end)
        except stac_client.StacQueryError as exc:
            QMessageBox.warning(self, "Ferramentas Terra", str(exc))
            return

        self.list_widget.clear()
        self.scenes = []
        self.btn_load.setEnabled(False)
        self.status_label.setText("Consultando {}...".format(dict(PROVIDER_ITEMS)[provider_key]))
        self.progress.show()
        self.btn_search.setEnabled(False)
        self.btn_cancel.setEnabled(True)

        self.request = imagery_bridge.SearchRequest(self)
        self.request.finished.connect(self._on_search_finished)
        self.request.start(provider_key, bbox, start, end)

    def _do_cancel(self):
        if self.request is not None:
            self.request.cancel()
        self.status_label.setText("Consulta cancelada.")
        self._search_ui_idle()

    def _search_ui_idle(self):
        self.progress.hide()
        self.btn_search.setEnabled(True)
        self.btn_cancel.setEnabled(False)

    def _on_search_finished(self, scenes, error):
        self._search_ui_idle()
        if error:
            self.status_label.setText("")
            QMessageBox.warning(self, "Ferramentas Terra", error)
            return
        self.scenes = stac_client.sort_by_acquisition(scenes)
        if not self.scenes:
            self.status_label.setText(
                "Nenhuma aquisição encontrada para essa área e período - não significa "
                "necessariamente que não exista, só que esta fonte não tem cobertura "
                "disponível aqui."
            )
            return
        self.status_label.setText(
            "{} aquisição(ões) encontrada(s).".format(len(self.scenes))
        )
        for scene in self.scenes:
            meta = stac_client.format_metadata(scene)
            label = "{}  |  nuvens: {}  |  {}".format(
                meta["aquisicao"], meta["nuvens"], meta["fonte"]
            )
            self.list_widget.addItem(QListWidgetItem(label))

    # ---------------------------------------------------------- metadados
    def _show_metadata(self, row):
        if row < 0 or row >= len(self.scenes):
            self.btn_load.setEnabled(False)
            self.meta_label.setText("Selecione uma aquisição na lista para ver os detalhes.")
            return
        meta = stac_client.format_metadata(self.scenes[row])
        self.meta_label.setText(
            "Aquisição: {}\nPublicação do produto: {}\nSatélite/sensor: {}\n"
            "Resolução espacial: {}\nCobertura de nuvens: {}\nFonte: {}\n"
            "Identificador do produto: {}".format(
                meta["aquisicao"],
                meta["publicacao"],
                meta["satelite"],
                meta["resolucao"],
                meta["nuvens"],
                meta["fonte"],
                meta["id_produto"],
            )
        )
        self.btn_load.setEnabled(True)

    # -------------------------------------------------------------- carregar
    def _selected_scene(self):
        row = self.list_widget.currentRow()
        if row < 0 or row >= len(self.scenes):
            return None
        return self.scenes[row]

    def _load_selected(self):
        scene = self._selected_scene()
        if scene is None:
            return
        self._load_scene(scene)

    def _load_scene(self, scene):
        layer, error = imagery_bridge.load_scene(scene)
        if error:
            QMessageBox.warning(self, "Ferramentas Terra", error)
            return None
        self.iface.messageBar().pushSuccess(
            "Ferramentas Terra", '"{}" carregada no mapa.'.format(layer.name())
        )
        return layer

    def _load_into_slot(self, slot):
        scene = self._selected_scene()
        if scene is None:
            QMessageBox.information(
                self, "Ferramentas Terra", "Selecione uma aquisição na lista primeiro."
            )
            return
        layer = self._load_scene(scene)
        if layer is None:
            return
        old = self.slot_layers.get(slot)
        if old is not None:
            try:
                QgsProject.instance().removeMapLayer(old.id())
            except Exception:
                pass
        self.slot_layers[slot] = layer
        meta = stac_client.format_metadata(scene)
        self.slot_status[slot].setText(meta["aquisicao"])
        self.slot_checks[slot].setEnabled(True)
        self.slot_checks[slot].setChecked(True)

    def _toggle_slot(self, slot, checked):
        layer = self.slot_layers.get(slot)
        if layer is None:
            return
        try:
            node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
            if node is not None:
                node.setItemVisibilityChecked(checked)
        except Exception:
            pass

    # ---------------------------------------------------------------- cache
    def _refresh_cache_label(self):
        size_kb = imagery_bridge.cache_size_bytes() / 1024.0
        self.cache_label.setText("Cache de busca: {:.1f} KB (só metadados, não imagens)".format(size_kb))

    def _do_clear_cache(self):
        removed = imagery_bridge.clear_cache()
        self._refresh_cache_label()
        self.iface.messageBar().pushInfo(
            "Ferramentas Terra", "{} arquivo(s) de cache removido(s).".format(removed)
        )

    # -------------------------------------------------------------- limpeza
    def closeEvent(self, event):
        if self.request is not None:
            self.request.cancel()
        super(ImageryDialog, self).closeEvent(event)
