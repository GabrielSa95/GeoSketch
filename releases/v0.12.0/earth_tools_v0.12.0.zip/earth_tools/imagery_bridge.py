# -*- coding: utf-8 -*-
"""Ponte entre stac_client.py (puro) e o QGIS: consulta assíncrona a um
catálogo STAC (não bloqueia o canvas), monta a composição RGB quando a
fonte não tem um asset único pronto (Landsat), carrega a cena escolhida
como camada raster, e mantém o cache de metadados em disco (Fase E).

Nada aqui toca no GeoPackage "Meus Lugares" nem em nenhuma geometria de
lugar - é só leitura de um serviço externo e criação de uma camada raster
nova no projeto, isolada de storage.py/places_model.py.
"""

import datetime as _dt
import hashlib
import json
import os
import tempfile

from qgis.core import QgsProject, QgsRasterLayer
from qgis.PyQt.QtCore import QByteArray, QObject, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest

from . import imagery_cache, stac_client, storage, utils

CACHE_DIR_NAME = "cache_imagens"


# -------------------------------------------------------------- cache local
def cache_dir():
    """Pasta local de cache de METADADOS (não imagens - ver
    imagery_cache.py), ao lado do GeoPackage "Meus Lugares" (mesmo critério
    de storage.gpkg_path: perto do projeto salvo, ou na pasta do usuário se
    o projeto ainda não foi salvo)."""
    base = os.path.dirname(storage.gpkg_path())
    path = os.path.join(base, CACHE_DIR_NAME)
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass
    return path


def _cache_file(key):
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return os.path.join(cache_dir(), digest + ".json")


def read_cache(provider_key, bbox, start, end):
    """[] cenas em cache se existirem e ainda não tiverem expirado (ver
    imagery_cache.DEFAULT_TTL_SECONDS); None se não houver nada
    aproveitável - força uma consulta nova."""
    key = imagery_cache.cache_key(provider_key, bbox, start, end)
    path = _cache_file(key)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        entry = {
            "cached_at": _dt.datetime.fromisoformat(data["cached_at"]),
            "scenes": data["scenes"],
        }
    except Exception:
        return None
    if not imagery_cache.should_use_cache(entry, _dt.datetime.now()):
        return None
    return entry["scenes"]


def write_cache(provider_key, bbox, start, end, scenes):
    key = imagery_cache.cache_key(provider_key, bbox, start, end)
    path = _cache_file(key)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"cached_at": _dt.datetime.now().isoformat(), "scenes": scenes}, f)
    except Exception as exc:
        utils.log("Falha ao gravar cache de busca de imagens: {}".format(exc), "warning")


def clear_cache():
    """Apaga só os arquivos de metadados em cache_dir(); nunca toca no
    GeoPackage nem em nenhuma camada já carregada no projeto. Devolve
    quantos arquivos foram removidos."""
    removed = 0
    directory = cache_dir()
    try:
        for name in os.listdir(directory):
            if name.endswith(".json"):
                try:
                    os.remove(os.path.join(directory, name))
                    removed += 1
                except OSError:
                    pass
    except OSError:
        pass
    return removed


def cache_size_bytes():
    total = 0
    directory = cache_dir()
    try:
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                total += os.path.getsize(path)
    except OSError:
        pass
    return total


# ---------------------------------------------------------------- consulta
class SearchRequest(QObject):
    """Consulta assíncrona a um catálogo STAC - usa QNetworkAccessManager
    (E/S de rede do próprio Qt/QGIS, que respeita a configuração de proxy
    do QGIS), nunca bloqueia o laço de eventos: o canvas continua
    respondendo enquanto a resposta não chega. Cancelável via cancel().
    """

    finished = pyqtSignal(list, str)  # scenes, mensagem_de_erro ("" = sem erro/cancelado)

    def __init__(self, parent=None):
        super(SearchRequest, self).__init__(parent)
        self._manager = QNetworkAccessManager(self)
        self._reply = None
        self._provider_key = None
        self._bbox = None
        self._start = None
        self._end = None

    def start(self, provider_key, bbox, start, end, limit=30, use_cache=True):
        if use_cache:
            cached = read_cache(provider_key, bbox, start, end)
            if cached is not None:
                self.finished.emit(cached, "")
                return
        try:
            body = stac_client.build_search_body(provider_key, bbox, start, end, limit)
        except stac_client.StacQueryError as exc:
            self.finished.emit([], str(exc))
            return

        self._provider_key = provider_key
        self._bbox, self._start, self._end = bbox, start, end
        request = QNetworkRequest(QUrl(stac_client.STAC_ENDPOINT))
        request.setHeader(QNetworkRequest.ContentTypeHeader, b"application/json")
        payload = QByteArray(json.dumps(body).encode("utf-8"))
        self._reply = self._manager.post(request, payload)
        self._reply.finished.connect(self._on_finished)

    def cancel(self):
        if self._reply is not None:
            self._reply.abort()

    def _on_finished(self):
        reply = self._reply
        self._reply = None
        if reply is None:
            return
        try:
            if reply.error() != QNetworkReply.NoError:
                if reply.error() == QNetworkReply.OperationCanceledError:
                    self.finished.emit([], "")  # cancelado pelo usuario: nao e um erro a mostrar
                    return
                status = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
                body_text = bytes(reply.readAll()).decode("utf-8", "ignore")
                message = stac_client.classify_http_error(status, body_text)
                utils.log("Falha na consulta de imagens: {}".format(message), "warning")
                self.finished.emit([], message)
                return

            raw = bytes(reply.readAll()).decode("utf-8", "ignore")
            try:
                data = json.loads(raw)
            except Exception as exc:
                self.finished.emit(
                    [], "A resposta do serviço de imagens não é um JSON válido: {}".format(exc)
                )
                return
            try:
                scenes = stac_client.parse_search_response(data, self._provider_key)
            except stac_client.StacResponseError as exc:
                utils.log("Resposta STAC com formato inesperado: {}".format(exc), "critical")
                self.finished.emit([], str(exc))
                return

            write_cache(self._provider_key, self._bbox, self._start, self._end, scenes)
            self.finished.emit(scenes, "")
        finally:
            reply.deleteLater()


# --------------------------------------------------------- carregar no mapa
def build_landsat_vrt(hrefs_rgb, name_hint="landsat"):
    """3 bandas remotas (red, green, blue) -> um VRT local empilhando-as
    como composição RGB. Usa gdal.BuildVRT (não XML escrito à mão: um VRT
    precisa do tamanho/georreferenciamento certos, que só se sabe lendo o
    cabeçalho de cada banda). O GDAL lê esse cabeçalho via /vsicurl/ (poucos
    KB, não o arquivo inteiro); os pixels só são buscados de fato quando o
    QGIS desenha a tela."""
    try:
        from osgeo import gdal
    except Exception as exc:
        raise IOError("módulo GDAL (osgeo) indisponível: {}".format(exc))

    vsicurl_paths = ["/vsicurl/{}".format(href) for href in hrefs_rgb]
    fd, path = tempfile.mkstemp(prefix="ferramentas_terra_{}_".format(name_hint), suffix=".vrt")
    os.close(fd)
    try:
        gdal.UseExceptions()
        options = gdal.BuildVRTOptions(separate=True)
        ds = gdal.BuildVRT(path, vsicurl_paths, options=options)
        if ds is None:
            raise IOError("gdal.BuildVRT não devolveu um dataset")
        ds.FlushCache()
        ds = None
    except Exception:
        try:
            os.remove(path)
        except OSError:
            pass
        raise
    return path


def load_scene(scene):
    """Carrega a cena escolhida como camada raster no projeto. Nunca toca
    em geometrias/GeoPackage de lugares - cria só uma QgsRasterLayer nova.
    Devolve (layer, erro): layer é None e erro vem preenchido se não for
    possível carregar."""
    kind, payload = stac_client.true_color_source(scene)
    meta = stac_client.format_metadata(scene)
    acquired_date = meta["aquisicao"][:10] if meta["aquisicao"] != "Não informado" else "?"
    name = "{} - {} (nuvens {})".format(meta["fonte"], acquired_date, meta["nuvens"])

    if kind == "cog":
        uri = "/vsicurl/{}".format(payload)
    elif kind == "bands":
        try:
            uri = build_landsat_vrt(payload, name_hint=scene.get("id", "landsat"))
        except Exception as exc:
            utils.log("Falha ao montar VRT do Landsat: {}".format(exc), "critical")
            return None, "Não foi possível montar a composição de bandas:\n{}".format(exc)
    else:
        return None, "Esta cena não tem bandas RGB suficientes para carregar."

    try:
        layer = QgsRasterLayer(uri, name)
    except Exception as exc:
        utils.log("Falha ao abrir camada de imagem: {}".format(exc), "critical")
        return None, "Não foi possível abrir a imagem:\n{}".format(exc)

    if not layer.isValid():
        utils.log("QgsRasterLayer inválida para a cena {}: {}".format(scene.get("id"), uri), "critical")
        return None, (
            "A imagem não pôde ser aberta - o arquivo remoto pode estar indisponível "
            "agora, ou a conexão falhou no meio da leitura."
        )

    QgsProject.instance().addMapLayer(layer)
    return layer, None
