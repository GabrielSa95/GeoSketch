# -*- coding: utf-8 -*-
"""Consulta a catálogos STAC de imagens de satélite (Fase E), sem depender
do PyQGIS - mesmo motivo de geometry_rules.py/folder_rules.py/
measure_rules.py/export_rules.py: fica testável com `python -m unittest`
puro. A chamada de rede em si (que precisa ser assíncrona, para não
bloquear o canvas) fica em imagery_bridge.py; aqui só a montagem da
consulta e a interpretação da resposta - a parte que pode (e deve) ser
verificada sem depender de uma conexão real a cada teste.

Provedor escolhido (ver releases/.../RELATORIO_vX.Y.Z.md para a
justificativa completa): Earth Search, da Element84, hospedado no
Programa de Dados Abertos da AWS - https://earth-search.aws.element84.com
Catálogo STAC público, sem autenticação, cobrindo Sentinel-2 (L2A) e
Landsat Collection 2 Nível 2. Confirmado por consulta real a este serviço
durante o desenvolvimento desta fase (não presumido pela documentação).

Licença dos DADOS (não o rótulo "proprietary" do campo `license` deste
catálogo STAC, que é um valor-padrão do Element84 e não reflete a licença
real): Sentinel-2 é dado aberto Copernicus/ESA (Copernicus Sentinel Data,
acesso livre e gratuito); Landsat Coleção 2 é domínio público
USGS/NASA. Ambos pedem citação da fonte, não uso comercial restrito.
"""

import datetime as _dt
import json

STAC_ENDPOINT = "https://earth-search.aws.element84.com/v1/search"

# gsd_m: resolução espacial nominal da banda usada (documentada pelo
# provedor, não inventada). visual_asset: um asset RGB já pronto (COG).
# rgb_bands: quando não há asset RGB pronto, as 3 bandas para compor um
# VRT (ver imagery_bridge.true_color_source/build_landsat_vrt).
PROVIDERS = {
    "sentinel2": {
        "label": "Sentinel-2 (L2A)",
        "collection": "sentinel-2-l2a",
        "gsd_m": 10,
        "visual_asset": "visual",
        "thumbnail_asset": "thumbnail",
        "rgb_bands": None,
    },
    "landsat": {
        "label": "Landsat (Coleção 2 Nível 2)",
        "collection": "landsat-c2-l2",
        "gsd_m": 30,
        "visual_asset": None,
        "thumbnail_asset": "thumbnail",
        "rgb_bands": ("red", "green", "blue"),
    },
}


class StacQueryError(ValueError):
    """Parâmetros de consulta inválidos - detectado ANTES de ir à rede."""


class StacResponseError(Exception):
    """Resposta do serviço com formato inesperado - distinto de "sem
    resultados", que é uma lista vazia válida, não um erro."""


# --------------------------------------------------------------- consulta
def validate_date_range(start, end, today=None):
    """start/end: datetime.date. Levanta StacQueryError com mensagem
    pronta para mostrar ao usuário se o intervalo for inválido. `today` é
    injetável para teste; por padrão usa a data real."""
    if today is None:
        today = _dt.date.today()
    if start is None or end is None:
        raise StacQueryError("Informe as duas datas do intervalo.")
    if start > end:
        raise StacQueryError("A data inicial não pode ser depois da data final.")
    if start > today:
        raise StacQueryError("A data inicial não pode ser no futuro.")
    return True


def validate_bbox(bbox):
    """bbox = (min_lon, min_lat, max_lon, max_lat), graus decimais."""
    if bbox is None or len(bbox) != 4:
        raise StacQueryError("Área de interesse inválida (esperado 4 coordenadas).")
    min_lon, min_lat, max_lon, max_lat = bbox
    for lon in (min_lon, max_lon):
        if not (-180.0 <= lon <= 180.0):
            raise StacQueryError("Longitude fora do intervalo -180 a 180.")
    for lat in (min_lat, max_lat):
        if not (-90.0 <= lat <= 90.0):
            raise StacQueryError("Latitude fora do intervalo -90 a 90.")
    if min_lon >= max_lon or min_lat >= max_lat:
        raise StacQueryError(
            "A área de interesse está vazia ou com os limites invertidos."
        )
    return True


def build_search_body(provider_key, bbox, start, end, limit=30):
    """Corpo JSON (dict) para POST no endpoint /search da API STAC.
    Levanta StacQueryError se algo for inválido - nunca manda uma
    consulta malformada à rede."""
    if provider_key not in PROVIDERS:
        raise StacQueryError("Fonte de imagens desconhecida: {}".format(provider_key))
    validate_bbox(bbox)
    validate_date_range(start, end)
    min_lon, min_lat, max_lon, max_lat = bbox
    return {
        "collections": [PROVIDERS[provider_key]["collection"]],
        "bbox": [min_lon, min_lat, max_lon, max_lat],
        "datetime": "{}T00:00:00Z/{}T23:59:59Z".format(start.isoformat(), end.isoformat()),
        "limit": limit,
    }


# ----------------------------------------------------------------- erros
def classify_http_error(status_code, body_text=""):
    """Mensagem amigável para um erro HTTP (ou ausência de resposta:
    status_code None/0 = falha de conexão, sem resposta nenhuma do
    servidor)."""
    if not status_code:
        return (
            "Não foi possível conectar ao serviço de imagens. Verifique sua conexão "
            "com a internet e tente novamente."
        )
    detail = None
    try:
        data = json.loads(body_text) if body_text else {}
        detail = data.get("description") or data.get("message")
    except Exception:
        pass
    if status_code == 400:
        return "Consulta inválida" + (": {}".format(detail) if detail else ".")
    if status_code in (401, 403):
        return "Acesso negado pelo serviço de imagens (HTTP {}).".format(status_code)
    if status_code == 404:
        return "Serviço de imagens não encontrado (HTTP 404) - o endereço pode ter mudado."
    if status_code >= 500:
        return "O serviço de imagens está indisponível agora (erro {}). Tente mais " \
               "tarde.".format(status_code)
    if detail:
        return "Erro {}: {}".format(status_code, detail)
    return "Erro inesperado do serviço de imagens (HTTP {}).".format(status_code)


# --------------------------------------------------------------- resposta
def parse_search_response(data, provider_key):
    """data = dict já decodificado do JSON da resposta (HTTP 200).
    Levanta StacResponseError se a FORMA da resposta for inesperada - uma
    lista de resultados vazia é válida e não levanta nada, é só uma
    consulta sem cobertura para a área/período."""
    if not isinstance(data, dict):
        raise StacResponseError(
            "A resposta do serviço de imagens não é um objeto JSON válido."
        )
    if "features" not in data:
        raise StacResponseError(
            "A resposta do serviço de imagens não tem o formato esperado "
            "(faltou o campo 'features')."
        )
    features = data["features"]
    if not isinstance(features, list):
        raise StacResponseError("O campo 'features' da resposta não é uma lista.")
    scenes = []
    for feature in features:
        scene = _parse_feature(feature, provider_key)
        if scene is not None:
            scenes.append(scene)
    return dedupe_scenes(scenes)


def _parse_feature(feature, provider_key):
    """Um item malformado não derruba a lista inteira - só é ignorado."""
    try:
        provider = PROVIDERS[provider_key]
        props = feature.get("properties") or {}
        assets = feature.get("assets") or {}
        scene_id = feature.get("id")
        acquired = props.get("datetime")
        if not scene_id or not acquired:
            return None  # sem os dois minimos, nao e util listar
        return {
            "id": scene_id,
            "provider": provider_key,
            "collection": provider["collection"],
            "acquired": acquired,  # ISO 8601 - data/hora de AQUISICAO
            "published": props.get("created"),  # ISO 8601 - PROCESSAMENTO/publicacao
            "platform": props.get("platform"),
            "cloud_cover": props.get("eo:cloud_cover"),
            "gsd_m": provider["gsd_m"],
            "bbox": feature.get("bbox"),
            "assets": assets,
        }
    except Exception:
        return None


def dedupe_scenes(scenes):
    """Remove duplicatas exatas de id, preservando a primeira ocorrência e
    a ordem - evita que o mesmo produto apareça duas vezes no catálogo
    mostrado (ex.: se a consulta for refeita e os resultados concatenados)."""
    seen = set()
    out = []
    for scene in scenes:
        sid = scene.get("id")
        if sid in seen:
            continue
        seen.add(sid)
        out.append(scene)
    return out


def sort_by_acquisition(scenes, newest_first=True):
    return sorted(scenes, key=lambda s: s.get("acquired") or "", reverse=newest_first)


# -------------------------------------------------------------- metadados
def format_metadata(scene):
    """{campo: texto}, com "Não informado" para o que faltar - nunca
    inventa um valor que o provedor não mandou."""

    def text_or_missing(value):
        return str(value) if value else "Não informado"

    cloud = scene.get("cloud_cover")
    cloud_text = "{:.1f}%".format(cloud) if isinstance(cloud, (int, float)) else "Não informado"
    gsd = scene.get("gsd_m")
    gsd_text = "{} m".format(gsd) if gsd else "Não informado"
    provider_label = PROVIDERS.get(scene.get("provider"), {}).get("label", "Não informado")

    return {
        "aquisicao": text_or_missing(scene.get("acquired")),
        "publicacao": text_or_missing(scene.get("published")),
        "satelite": text_or_missing(scene.get("platform")),
        "resolucao": gsd_text,
        "nuvens": cloud_text,
        "fonte": provider_label,
        "id_produto": text_or_missing(scene.get("id")),
        "extensao": text_or_missing(scene.get("bbox")),
    }


def true_color_source(scene):
    """Devolve ("cog", href) se houver um único asset RGB já pronto
    (Sentinel-2 "visual"), ("bands", (href_r, href_g, href_b)) se precisar
    compor 3 bandas (Landsat), ou (None, None) se não houver o
    suficiente nos assets da cena."""
    provider = PROVIDERS.get(scene.get("provider"), {})
    assets = scene.get("assets") or {}

    visual_key = provider.get("visual_asset")
    if visual_key and visual_key in assets:
        href = (assets[visual_key] or {}).get("href")
        if href:
            return "cog", href

    bands = provider.get("rgb_bands")
    if bands:
        hrefs = []
        for band in bands:
            asset = assets.get(band)
            href = asset.get("href") if asset else None
            if not href:
                return None, None
            hrefs.append(href)
        return "bands", tuple(hrefs)

    return None, None
