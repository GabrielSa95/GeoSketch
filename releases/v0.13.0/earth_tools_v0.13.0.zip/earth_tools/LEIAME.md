# Ferramentas Terra — plugin QGIS

Barra de ferramentas que reproduz o fluxo de trabalho do Google Earth Pro dentro
do QGIS: marcador, polígono, caminho e régua, sem o usuário precisar criar
camada, escolher SRC, definir campos ou alternar o modo de edição.

## Instalação

1. No QGIS: **Complementos > Gerenciar e Instalar Complementos > Instalar a partir do ZIP**
2. Escolha o arquivo `ferramentas_terra.zip`
3. Clique em **Instalar Complemento**
4. A barra aparece na parte de cima. Se não aparecer: **Ver > Barras de Ferramentas > Ferramentas Terra**

Instalação manual (para distribuir na rede da empresa): copie a pasta
`earth_tools` para dentro de

- Windows: `C:\Users\SEU_USUARIO\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

Depois reinicie o QGIS e ative em Complementos > Gerenciar.

## Os botões

| Ícone | O que faz |
|---|---|
| Marcador | Abre a janela Novo Marcador. Clique no mapa **ou** digite latitude/longitude. |
| Polígono | Abre a janela Novo Polígono. Clique os cantos; a aba Medidas mostra área e perímetro ao vivo. |
| Caminho | Igual ao polígono, mas em linha aberta, com comprimento ao vivo. |
| Régua | Abas Linha, Caminho, Polígono e Círculo, com troca de unidade e botão Salvar. |
| Pasta | Cria uma pasta nova para organizar lugares (ver "Organizando em pastas"). |
| Globo | Abre o Google Maps no navegador, na mesma vista e coordenada do mapa. |
| Alvo | "Ir para coordenadas": digita latitude/longitude e centraliza o mapa. |
| Lupa | "Pesquisar lugares": filtra pelo nome e navega até o lugar escolhido. |
| Imagem+mapa | "Imagens de satélite": busca e carrega Sentinel-2/Landsat (ver seção própria). |
| Tela cheia | Alterna a tela cheia do QGIS (o mesmo item do menu Ver). |

## Como desenhar e corrigir

- **Clique simples** adiciona um vértice.
- **Botão direito** ou **duplo clique** encerra o desenho.
- **Clique e arraste um vértice já colocado** move ele; soltar confirma a posição.
- **Botão direito sobre um vértice** apaga só aquele vértice, sem encerrar o desenho.
- **Backspace** apaga o último vértice.
- **Esc** cancela e começa de novo.
- **Ctrl+Z** desfaz e **Ctrl+Y** (ou Ctrl+Shift+Z) refaz a última mudança de vértice —
  tanto durante o desenho quanto editando um lugar já salvo (nesse caso, desfazer também
  regrava o arquivo, não é só visual).
- Clicar fora de qualquer vértice, na janela **Editar**, estende o desenho com um
  vértice novo no final.
- A janela fica aberta o tempo todo e pode ser arrastada para o lado, igual à do
  Google Earth. O botão OK só habilita quando há vértices suficientes.

## Aderência e entrada numérica

- Caixa **Aderência a vértices/segmentos**, no topo das janelas de criação e edição:
  ativada por padrão, adere o clique/arraste a um vértice ou trecho de qualquer camada
  do projeto. Um **X** magenta mostra onde aderirira antes de você clicar. Desative a
  caixa para desligar na hora. A tolerância é em **pixels de tela** (não em metros/graus),
  então o comportamento não muda com o SRC do projeto nem com o zoom. Não se aplica ao
  círculo nem à Régua, que mantêm o comportamento de sempre.
- Aba **Adicionar por medida**, em linhas e polígonos: acrescenta um vértice no final do
  desenho por **distância e azimute** (azimute em graus, a partir do Norte, sentido
  horário — a mesma convenção do rumo mostrado na aba Linha da Régua) ou por
  **coordenadas** (latitude/longitude). As medidas e a prévia no mapa atualizam na hora,
  igual a um clique manual, e entram na mesma pilha de desfazer/refazer (Ctrl+Z).

## Importar e exportar KML/KMZ

Desde a versão 0.13.0, **Importar KML/KMZ...** e **Exportar pasta para KML/KMZ...** não
têm mais botão na barra principal (para deixá-la mais curta) — continuam disponíveis em
dois lugares, sem duplicar a lógica entre eles:

- Menu **Vetor > Ferramentas Terra**: igual a antes, pede o arquivo (importar) ou a
  pasta/escopo (exportar) na própria janela.
- **Botão direito numa pasta**, no painel Camadas: **Importar KML/KMZ para esta
  pasta...** e **Exportar esta pasta para KML/KMZ...** abrem a mesma janela já com
  aquela pasta escolhida e travada (clicou, já era). Se a pasta fizer parte de um
  **Modelo de propriedade rural**, aparece também **Exportar propriedade completa...**,
  que exporta a pasta-mãe inteira (Sede, APP, Reserva Legal...) mesmo clicando numa
  subpasta.

Em qualquer um dos caminhos: escolha o arquivo, confira a lista de marcadores/caminhos/
polígonos encontrados (tudo marcado por padrão, exceto o que já foi importado antes nesta
mesma pasta de trabalho — identificado pela geometria e nome, não só pelo nome do
arquivo) e clique em Importar. Pastas e subpastas do KML são recriadas dentro da pasta
escolhida. Elementos que o plugin não sabe representar (como `NetworkLink` ou
sobreposições de imagem) aparecem listados, mas não travam a importação do resto do
arquivo. Exportar uma pasta inclui as subpastas; para exportar **um único lugar**, use
botão direito na camada > **Salvar lugar como...** (ou **Enviar por e-mail...**), que
também aceita KMZ.
- Nomes, descrições e as cores/largura de linha e preenchimento suportadas são
  preservados nos dois sentidos. **Ícones personalizados do Google Earth e alguns
  recursos visuais específicos dele não têm equivalente garantido** neste formato —
  não é uma reprodução pixel a pixel.
- Um polígono do KML com `MultiGeometry` (várias partes numa única feição) vira vários
  lugares separados na importação (ex.: "Nome (1)", "Nome (2)"), já que cada lugar do
  plugin é sempre uma única geometria simples.

## Imagens de satélite e histórico temporal

Botão **Imagens de satélite**: busca aquisições de Sentinel-2 ou Landsat para a extensão
atual do mapa ou para um lugar selecionado, num período escolhido, e organiza o
resultado numa **linha do tempo anual** (estilo Google Earth Pro).

- **Fonte dos dados:** [Earth Search](https://earth-search.aws.element84.com), um
  catálogo STAC público mantido pela Element84 no Programa de Dados Abertos da AWS.
  Não exige cadastro nem chave de acesso. Sentinel-2 é dado aberto Copernicus/ESA;
  Landsat Coleção 2 é domínio público USGS/NASA. **Este é um serviço gratuito mantido por
  terceiros, sem garantia contratual de disponibilidade** — se ele estiver fora do ar ou
  mudar de endereço, a busca falha com uma mensagem clara, mas o resto do plugin
  (desenho, edição, régua, lugares salvos) continua funcionando normalmente.
- Clicar em **"Buscar / atualizar nesta área"** sempre usa a área e o período escolhidos
  naquele momento — mover o mapa não refaz a busca por conta própria; depois de deslocar
  a área, clique de novo para atualizar.
- **Linha do tempo:** depois da busca, os anos do período aparecem numa trilha
  horizontal. Anos **desabilitados** não têm nenhuma aquisição encontrada nessa fonte/
  período — eles continuam visíveis (não somem da trilha), só para não dar a impressão de
  que o intervalo pesquisado é mais curto do que é. As setas **"◀ ano" / "ano ▶"** pulam
  direto para o próximo ano *com* aquisição, mesmo que existam vários anos vazios entre
  um e outro. Clicar num ano carrega automaticamente a aquisição mais recente dele.
- Dentro de um ano, a lista mostra as aquisições daquele ano, da mais antiga para a mais
  nova, com data exata, satélite e nuvens; quando a cena não cobre 100% da área
  pesquisada (a busca encontra qualquer cena que *toque* a área, não só as que cobrem
  tudo), aparece "cobertura da área visível: NN%" — nunca é escondido. As setas
  **"◀ aquisição anterior" / "aquisição seguinte ▶"** avançam/retrocedem sem precisar
  voltar à tela de busca, inclusive passando para o ano vizinho quando chegam na ponta.
- O rótulo em negrito abaixo de "Carregar no mapa" mostra a data **realmente carregada**
  no mapa agora — se uma tentativa de carregar falhar, a última imagem válida continua lá
  e uma mensagem avisa o que deu errado, sem apagar nada.
- "Carregar no mapa" (e a troca de ano/aquisição) abre a imagem em cores naturais (RGB)
  direto do arquivo remoto, sem baixar o arquivo inteiro primeiro (streaming do GDAL),
  preservando o enquadramento atual do mapa. Para o Landsat (e Sentinel-2 quando a cena
  não tiver a imagem RGB já pronta), o plugin monta essa composição a partir das 3 bandas
  — com o realce de contraste e o recorte de valores sem cobertura aplicados
  automaticamente, para a imagem não aparecer lavada/acinzentada.
- **Comparar duas datas:** carregue uma aquisição em "Anterior" e outra em "Posterior";
  as caixas de marcar alternam qual fica visível, sem mudar o zoom/enquadramento. Para um
  slider de comparação lado a lado, use a ferramenta nativa do próprio QGIS (**Mapa
  comparativo**/Map Swipe Tool) — não foi reimplementada aqui.
- **Datas diferentes não são uma comparação perfeita:** resolução, cobertura de nuvens,
  ângulo do sol e até o sensor podem variar entre duas aquisições.
- O cache guarda só os **metadados** de cada busca (por algumas horas, para não repetir a
  mesma consulta sem necessidade) — nunca as imagens em si. Botão "Limpar cache de
  busca" apaga esses metadados; nunca apaga lugares nem camadas já carregadas.
- Consultas de rede não travam o mapa (rodam em segundo plano, com botão de cancelar).
  Sem internet, a busca falha com aviso — o restante do plugin não é afetado. Trocar de
  área/período antes de a busca anterior responder descarta a resposta antiga
  automaticamente — ela nunca sobrescreve o resultado de uma busca mais nova.

## Onde os dados ficam

Tudo vai para um único arquivo `Meus Lugares.gpkg`, com três camadas dentro
(Marcadores, Caminhos, Polígonos). O arquivo fica na pasta do projeto salvo; se
o projeto ainda não foi salvo, vai para `Meus Lugares QGIS` na pasta do usuário.
Não é camada temporária — não se perde ao fechar o QGIS.

O campo **Pasta** faz o papel das pastas de Meus Lugares (ex.: "Chácara Recanto
Vitória"). Ele sugere as pastas já usadas conforme você digita.

Para mandar para quem usa Google Earth: botão direito na camada >
**Exportar > Salvar feições como** > formato **KML**.

## Unidades disponíveis

Comprimento: metros, quilômetros, centímetros, pés, jardas, milhas, milhas náuticas.
Área: metros quadrados, hectares, quilômetros quadrados, **alqueire paulista**,
**alqueire mineiro**, acres, pés quadrados.

Todas as medições são feitas sobre o elipsoide WGS84, não em projeção plana, então
a área não muda conforme o SRC do projeto.

## Organizando em pastas

- Botão **Pasta** (ou botão direito no painel Camadas > **Adicionar > Pasta**) cria uma
  pasta. Clicar com uma pasta já selecionada cria uma subpasta dentro dela.
- **Modelo de propriedade rural** (botão direito > Adicionar): cria de uma vez a pasta do
  imóvel com as subpastas padrão **Sede, Área do Imóvel, APP, Reserva Legal, Nascentes e
  Outros**.
- Para mover um lugar entre pastas: **arraste e solte** no painel Camadas (recurso nativo
  do QGIS) **ou** botão direito no lugar > **Mover para pasta...** — essa segunda opção
  grava a mudança imediatamente; o arrastar-e-soltar fica gravado no arquivo quando o
  projeto é salvo.
- Mostrar/ocultar uma pasta inteira: desmarque a caixinha da pasta na árvore, como em
  qualquer grupo do QGIS — esconde todos os lugares dentro dela no mapa.
- Renomear uma pasta: duplo clique no nome, como em qualquer grupo do QGIS.
- Excluir uma pasta (botão direito > Excluir, ou tecla Delete) pede confirmação e apaga
  os lugares que estiverem dentro dela do arquivo `Meus Lugares.gpkg` — leia o aviso
  antes de confirmar.
- Botão **Lupa** ("Pesquisar lugares") acha um lugar pelo nome e leva você até ele, sem
  precisar procurar na árvore.
- A organização em pastas fica guardada dentro do próprio `Meus Lugares.gpkg` (não só no
  arquivo de projeto do QGIS), então sobrevive mesmo se você fechar o QGIS sem salvar o
  projeto.

## Limitações conhecidas

- As abas **Caminho em 3D** e **Polígono em 3D** da régua estão desativadas: elas
  dependem de um modelo digital de elevação configurado no projeto.
- O campo Descrição aceita HTML (link e imagem), mas o QGIS só mostra formatado
  se você configurar um mapa de identificação HTML na camada.
- Pastas criadas pelo plugin só reconhecem como "pasta-mãe" outra pasta também criada
  pelo plugin. Se você selecionar um grupo de camadas qualquer do QGIS (não criado pelo
  botão Pasta) ao criar uma pasta nova, ela nasce na raiz, não dentro desse grupo.
- A ordem dentro de uma mesma pasta (qual lugar vem antes de qual) não é garantida após
  reabrir o projeto — só a relação de "está dentro de qual pasta" é preservada.
- Imagens de satélite: o acervo disponível começa em 2015 (Sentinel-2) ou é mais antigo
  mas com resolução pior para Landsat; não existe um equivalente ao acervo histórico de
  fotos aéreas antigas do Google Earth. A busca depende de um serviço gratuito de
  terceiros (Earth Search/AWS), sem garantia contratual de disponibilidade.

## Requisitos

QGIS 3.22 ou superior. Testado no fluxo do QGIS 3.34 LTR e 3.44.
