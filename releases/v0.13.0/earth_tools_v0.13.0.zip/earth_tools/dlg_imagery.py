# -*- coding: utf-8 -*-
"""Janela "Imagens de satélite" (Fase E, reorganizada na Fase F): busca
Sentinel-2/Landsat por área e período, mostra os metadados disponíveis,
organiza as aquisições encontradas numa linha do tempo anual (estilo
Google Earth Pro) e permite alternar entre duas datas para comparação
visual simples.

Não toca no GeoPackage "Meus Lugares" nem em nenhuma geometria - só cria
camadas raster novas no projeto. Funciona de forma assíncrona (não
congela o canvas); se a internet estiver indisponível, só esta janela é
afetada - desenho, edição, régua e lugares salvos continuam funcionando.

Fase F: a busca agora verifica se a cena cobre de fato a área pesquisada
(a consulta STAC filtra por intersecção de bbox, não por conter a área
inteira - ver stac_client.coverage_fraction) e nunca troca a imagem
"atual" no mapa antes de a nova camada ser validada, preservando o
enquadramento do canvas. Ver releases/v0.13.0/RELATORIO_v0.13.0.md para a
causa raiz completa dos problemas corrigidos nesta fase.
"""

import datetime as _dt

from qgis.core import QgsCoordinateTransform, QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QCursor
from qgis.PyQt.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from . import imagery_bridge, imagery_timeline, stac_client, storage, utils

PROVIDER_ITEMS = [("sentinel2", "Sentinel-2 (L2A)"), ("landsat", "Landsat (Coleção 2 Nível 2)")]
MIN_COVERAGE_TO_WARN = 0.999  # abaixo disso, mostra a cobertura real na lista/rótulo


class ImageryDialog(QDialog):
    def __init__(self, iface, parent=None):
        super(ImageryDialog, self).__init__(parent)
        self.iface = iface
        self.scenes = []  # todas as cenas da ultima busca, qualquer ano
        self.year_track = []  # [{"year", "has_scenes", "count"}]
        self.year_scenes = []  # cenas so do ano selecionado, cronologicas
        self.current_year = None
        self.current_scene = None  # cena efetivamente carregada no mapa agora
        self.current_layer = None  # camada "principal" (fora dos slots A/B)
        self.slot_layers = {"A": None, "B": None}
        self.request = None
        self._search_generation = 0
        self._last_query_bbox = None
        self._prev_year_target = None
        self._next_year_target = None
        self._year_buttons = {}

        self.setWindowTitle("Ferramentas Terra - Imagens de satélite")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setModal(False)
        self.setMinimumSize(520, 680)

        layout = QVBoxLayout(self)

        note = QLabel(
            "Fonte: Earth Search (Element84), catálogo público Sentinel-2/Landsat, sem "
            "necessidade de cadastro. Datas diferentes podem ter resolução, cobertura de "
            "nuvens e condições de iluminação diferentes - não são uma comparação "
            "perfeitamente equivalente."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #555; font-style: italic;")
        layout.addWidget(note)

        form = QFormLayout()
        self.area_combo = QComboBox()
        self.area_combo.addItems(["Extensão atual do mapa", "Feição selecionada"])
        form.addRow("Área de interesse:", self.area_combo)

        self.provider_combo = QComboBox()
        for key, label in PROVIDER_ITEMS:
            self.provider_combo.addItem(label, key)
        form.addRow("Fonte:", self.provider_combo)

        dates_row = QHBoxLayout()
        self.start_edit = QDateEdit(calendarPopup=True)
        self.start_edit.setDate(_dt.date.today() - _dt.timedelta(days=365 * 5))
        self.end_edit = QDateEdit(calendarPopup=True)
        self.end_edit.setDate(_dt.date.today())
        dates_row.addWidget(self.start_edit)
        dates_row.addWidget(QLabel("até"))
        dates_row.addWidget(self.end_edit)
        form.addRow("Período:", dates_row)
        layout.addLayout(form)

        search_row = QHBoxLayout()
        self.btn_search = QPushButton("Buscar / atualizar nesta área")
        self.btn_search.setToolTip(
            "Sempre usa a área e o período escolhidos ACIMA no momento do clique - "
            "mover o mapa não refaz a busca por conta própria; clique aqui de novo "
            "depois de deslocar/ajustar a área para atualizar os resultados."
        )
        self.btn_cancel = QPushButton("Cancelar consulta")
        self.btn_cancel.setEnabled(False)
        search_row.addWidget(self.btn_search)
        search_row.addWidget(self.btn_cancel)
        layout.addLayout(search_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)  # indeterminado - nao sabemos a duracao da consulta
        self.progress.hide()
        layout.addWidget(self.progress)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        # ------------------------------------------------- linha do tempo
        timeline_box = QGroupBox("Linha do tempo")
        timeline_layout = QVBoxLayout(timeline_box)

        year_row = QHBoxLayout()
        self.btn_prev_year = QToolButton()
        self.btn_prev_year.setText("◀ ano")
        self.btn_prev_year.setEnabled(False)
        self.btn_prev_year.setToolTip("Ano anterior com aquisição disponível.")
        year_row.addWidget(self.btn_prev_year)

        self.year_strip_widget = QWidget()
        self.year_strip_layout = QHBoxLayout(self.year_strip_widget)
        self.year_strip_layout.setContentsMargins(2, 2, 2, 2)
        self.year_strip_scroll = QScrollArea()
        self.year_strip_scroll.setWidget(self.year_strip_widget)
        self.year_strip_scroll.setWidgetResizable(True)
        self.year_strip_scroll.setFixedHeight(48)
        self.year_strip_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.year_strip_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        year_row.addWidget(self.year_strip_scroll)

        self.btn_next_year = QToolButton()
        self.btn_next_year.setText("ano ▶")
        self.btn_next_year.setEnabled(False)
        self.btn_next_year.setToolTip("Próximo ano com aquisição disponível.")
        year_row.addWidget(self.btn_next_year)
        timeline_layout.addLayout(year_row)

        self.year_hint_label = QLabel(
            "Anos em cinza/desabilitados não têm aquisição encontrada nesta fonte e "
            "período - não significa necessariamente que não exista imagem, só que esta "
            "busca não encontrou nenhuma."
        )
        self.year_hint_label.setWordWrap(True)
        self.year_hint_label.setStyleSheet("color: #555; font-style: italic;")
        timeline_layout.addWidget(self.year_hint_label)

        scene_row = QHBoxLayout()
        self.btn_prev_scene = QPushButton("◀ aquisição anterior")
        self.btn_prev_scene.setEnabled(False)
        self.btn_next_scene = QPushButton("aquisição seguinte ▶")
        self.btn_next_scene.setEnabled(False)
        scene_row.addWidget(self.btn_prev_scene)
        scene_row.addWidget(self.btn_next_scene)
        timeline_layout.addLayout(scene_row)

        self.year_label = QLabel("Busque uma área para ver os anos com aquisição disponível.")
        self.year_label.setWordWrap(True)
        timeline_layout.addWidget(self.year_label)

        self.list_widget = QListWidget()
        timeline_layout.addWidget(self.list_widget)

        layout.addWidget(timeline_box)

        self.meta_label = QLabel("Selecione uma aquisição na lista para ver os detalhes.")
        self.meta_label.setWordWrap(True)
        layout.addWidget(self.meta_label)

        load_row = QHBoxLayout()
        self.btn_load = QPushButton("Carregar no mapa")
        self.btn_load.setEnabled(False)
        load_row.addWidget(self.btn_load)
        layout.addLayout(load_row)

        self.loaded_label = QLabel("")
        self.loaded_label.setWordWrap(True)
        self.loaded_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.loaded_label)

        compare_box = QGroupBox("Comparar duas datas")
        compare_layout = QVBoxLayout(compare_box)
        self.compare_label = QLabel(
            "Carregue uma aquisição em \"Anterior\" e outra em \"Posterior\"; use as caixas "
            "para alternar qual fica visível, sem perder o enquadramento do mapa. Para um "
            "slider de comparação lado a lado, use a ferramenta nativa do QGIS "
            "Ver > Painéis > Mapa comparativo (Map Swipe Tool)."
        )
        self.compare_label.setWordWrap(True)
        self.compare_label.setStyleSheet("color: #555; font-style: italic;")
        compare_layout.addWidget(self.compare_label)

        self.slot_checks = {}
        self.slot_status = {}
        for slot, title in (("A", "Anterior"), ("B", "Posterior")):
            row = QHBoxLayout()
            check = QCheckBox("Mostrar " + title)
            check.setEnabled(False)
            check.toggled.connect(lambda checked, s=slot: self._toggle_slot(s, checked))
            status = QLabel("(nenhuma carregada)")
            btn = QPushButton("Carregar aqui")
            btn.clicked.connect(lambda _checked, s=slot: self._load_into_slot(s))
            row.addWidget(btn)
            row.addWidget(check)
            row.addWidget(status)
            row.addStretch()
            compare_layout.addLayout(row)
            self.slot_checks[slot] = check
            self.slot_status[slot] = status
        layout.addWidget(compare_box)

        cache_row = QHBoxLayout()
        self.cache_label = QLabel()
        self.btn_clear_cache = QPushButton("Limpar cache de busca")
        cache_row.addWidget(self.cache_label)
        cache_row.addStretch()
        cache_row.addWidget(self.btn_clear_cache)
        layout.addLayout(cache_row)
        self._refresh_cache_label()

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.close)
        layout.addWidget(buttons)

        self.btn_search.clicked.connect(self._do_search)
        self.btn_cancel.clicked.connect(self._do_cancel)
        self.btn_prev_year.clicked.connect(lambda: self._jump_to_year(self._prev_year_target))
        self.btn_next_year.clicked.connect(lambda: self._jump_to_year(self._next_year_target))
        self.btn_prev_scene.clicked.connect(lambda: self._step_acquisition(-1))
        self.btn_next_scene.clicked.connect(lambda: self._step_acquisition(1))
        self.list_widget.currentRowChanged.connect(self._show_metadata)
        self.list_widget.itemDoubleClicked.connect(lambda _item: self._load_selected())
        self.btn_load.clicked.connect(self._load_selected)
        self.btn_clear_cache.clicked.connect(self._do_clear_cache)

    # -------------------------------------------------------------- area
    def _current_bbox(self):
        """(min_lon, min_lat, max_lon, max_lat) em WGS84, ou (None, mensagem).

        Para a extensão do mapa, usa transformBoundingBox (um retângulo
        envolvente de verdade), em vez de converter só os dois cantos
        opostos ponto a ponto - impreciso para CRS projetado (o caso comum
        deste plugin: SIRGAS/UTM), que podia produzir uma área de busca
        deslocada da área real visível no canvas."""
        canvas = self.iface.mapCanvas()
        if self.area_combo.currentIndex() == 0:
            extent = canvas.extent()
            crs = canvas.mapSettings().destinationCrs()
            if crs == utils.WGS84:
                bbox_rect = extent
            else:
                try:
                    transform = QgsCoordinateTransform(crs, utils.WGS84, QgsProject.instance())
                    bbox_rect = transform.transformBoundingBox(extent)
                except Exception as exc:
                    return None, "Não foi possível converter a extensão do mapa:\n{}".format(exc)
            min_lon, max_lon = bbox_rect.xMinimum(), bbox_rect.xMaximum()
            min_lat, max_lat = bbox_rect.yMinimum(), bbox_rect.yMaximum()
        else:
            layer = None
            try:
                layer = self.iface.layerTreeView().currentLayer()
            except Exception:
                pass
            if layer is None or not storage.is_place_layer(layer):
                return None, "Selecione um lugar criado pelo plugin no painel Camadas primeiro."
            extent = layer.extent()  # lugares ja estao em EPSG:4326
            min_lon, max_lon = extent.xMinimum(), extent.xMaximum()
            min_lat, max_lat = extent.yMinimum(), extent.yMaximum()

        if max_lon - min_lon < 0.001 or max_lat - min_lat < 0.001:
            # feicao pontual ou extensao quase nula: aplica uma folga para
            # a busca ter uma area de verdade para consultar.
            pad = 0.01
            cx, cy = (min_lon + max_lon) / 2.0, (min_lat + max_lat) / 2.0
            min_lon, max_lon = cx - pad, cx + pad
            min_lat, max_lat = cy - pad, cy + pad
        return (min_lon, min_lat, max_lon, max_lat), None

    # ------------------------------------------------------------- busca
    def _do_search(self):
        bbox, error = self._current_bbox()
        if bbox is None:
            QMessageBox.information(self, "Ferramentas Terra", error)
            return

        provider_key = self.provider_combo.currentData()
        start = self.start_edit.date().toPyDate()
        end = self.end_edit.date().toPyDate()
        try:
            stac_client.validate_date_range(start, end)
        except stac_client.StacQueryError as exc:
            QMessageBox.warning(self, "Ferramentas Terra", str(exc))
            return

        # Qualquer resposta pendente de uma busca anterior passa a ser
        # ignorada - nunca deve sobrescrever os resultados desta busca nova.
        self._search_generation += 1
        generation = self._search_generation
        if self.request is not None:
            try:
                self.request.finished.disconnect()
            except Exception:
                pass
            self.request.cancel()

        self._last_query_bbox = bbox
        self._reset_timeline_ui()
        self.status_label.setText("Consultando {}...".format(dict(PROVIDER_ITEMS)[provider_key]))
        self.progress.show()
        self.btn_search.setEnabled(False)
        self.btn_cancel.setEnabled(True)

        self.request = imagery_bridge.SearchRequest(self)
        self.request.finished.connect(
            lambda scenes, err, g=generation: self._on_search_finished(g, scenes, err)
        )
        self.request.start(provider_key, bbox, start, end)

    def _do_cancel(self):
        if self.request is not None:
            self.request.cancel()
        self.status_label.setText("Consulta cancelada.")
        self._search_ui_idle()

    def _search_ui_idle(self):
        self.progress.hide()
        self.btn_search.setEnabled(True)
        self.btn_cancel.setEnabled(False)

    def _reset_timeline_ui(self):
        self.scenes = []
        self.year_track = []
        self.year_scenes = []
        self.current_year = None
        self._clear_year_buttons()
        self.list_widget.clear()
        self.btn_load.setEnabled(False)
        self.btn_prev_year.setEnabled(False)
        self.btn_next_year.setEnabled(False)
        self.btn_prev_scene.setEnabled(False)
        self.btn_next_scene.setEnabled(False)
        self.year_label.setText("Buscando...")

    def _on_search_finished(self, generation, scenes, error):
        if generation != self._search_generation:
            return  # resposta de uma busca ja substituida por outra mais nova
        self._search_ui_idle()
        if error:
            self.status_label.setText("")
            self.year_label.setText("Busque uma área para ver os anos com aquisição disponível.")
            QMessageBox.warning(self, "Ferramentas Terra", error)
            return

        self.scenes = stac_client.sort_by_acquisition(scenes)
        start = self.start_edit.date().toPyDate()
        end = self.end_edit.date().toPyDate()
        self.year_track = imagery_timeline.build_year_track(start, end, self.scenes)

        if not self.scenes:
            self.status_label.setText(
                "Nenhuma aquisição encontrada para essa área e período - não significa "
                "necessariamente que não exista, só que esta fonte não tem cobertura "
                "disponível aqui."
            )
            self.year_label.setText("Nenhum ano deste período tem aquisição disponível.")
            self._build_year_buttons()
            return

        self.status_label.setText(
            "{} aquisição(ões) encontrada(s).".format(len(self.scenes))
        )
        self._build_year_buttons()
        anos_com_dado = [e["year"] for e in self.year_track if e["has_scenes"]]
        self._jump_to_year(max(anos_com_dado))

    # --------------------------------------------------------- linha do tempo
    def _clear_year_buttons(self):
        while self.year_strip_layout.count():
            item = self.year_strip_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        self._year_buttons = {}
        self._year_button_group = None

    def _build_year_buttons(self):
        self._clear_year_buttons()
        self._year_button_group = QButtonGroup(self)
        self._year_button_group.setExclusive(True)
        for entry in self.year_track:
            year = entry["year"]
            btn = QToolButton()
            btn.setText(str(year))
            btn.setCheckable(True)
            btn.setEnabled(entry["has_scenes"])
            btn.setMinimumWidth(56)
            if entry["has_scenes"]:
                btn.setToolTip("{} aquisição(ões) encontrada(s).".format(entry["count"]))
            else:
                btn.setToolTip("Nenhuma aquisição encontrada para este ano.")
            btn.clicked.connect(lambda _checked, y=year: self._jump_to_year(y))
            self._year_button_group.addButton(btn)
            self.year_strip_layout.addWidget(btn)
            self._year_buttons[year] = btn
        self.year_strip_layout.addStretch()

    def _jump_to_year(self, year, scene_to_load=None):
        if year is None or year not in self._year_buttons:
            return
        self.current_year = year
        for y, btn in self._year_buttons.items():
            btn.setChecked(y == year)
        self.year_scenes = imagery_timeline.scenes_for_year(self.scenes, year)
        self._update_year_nav_buttons()

        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        for scene in self.year_scenes:
            self.list_widget.addItem(QListWidgetItem(self._scene_list_text(scene)))
        self.list_widget.blockSignals(False)

        if not self.year_scenes:
            self.year_label.setText("Ano {}: nenhuma aquisição encontrada.".format(year))
            self.btn_load.setEnabled(False)
            self.btn_prev_scene.setEnabled(False)
            self.btn_next_scene.setEnabled(False)
            return

        self.year_label.setText(
            "Aquisições em {} ({} encontrada(s)):".format(year, len(self.year_scenes))
        )
        target = scene_to_load if scene_to_load is not None else self.year_scenes[-1]
        self._select_scene_in_list(target)
        self._load_as_current(target)

    def _scene_list_text(self, scene):
        meta = stac_client.format_metadata(scene)
        texto = "{}  |  {}  |  nuvens {}".format(meta["aquisicao"], meta["satelite"], meta["nuvens"])
        coverage = stac_client.coverage_fraction(self._last_query_bbox, scene.get("bbox"))
        if coverage is not None and coverage < MIN_COVERAGE_TO_WARN:
            texto += "  |  cobertura da área visível: {:.0f}%".format(coverage * 100)
        return texto

    def _select_scene_in_list(self, scene):
        for i, candidate in enumerate(self.year_scenes):
            if candidate.get("id") == scene.get("id"):
                self.list_widget.setCurrentRow(i)
                return

    def _update_year_nav_buttons(self):
        self._prev_year_target = imagery_timeline.nearest_year_with_scenes(
            self.year_track, self.current_year, -1
        )
        self._next_year_target = imagery_timeline.nearest_year_with_scenes(
            self.year_track, self.current_year, 1
        )
        self.btn_prev_year.setEnabled(self._prev_year_target is not None)
        self.btn_next_year.setEnabled(self._next_year_target is not None)

    def _step_acquisition(self, direction):
        if self.current_scene is None or self.current_year is None:
            return
        nxt = imagery_timeline.adjacent_scene(self.year_scenes, self.current_scene.get("id"), direction)
        if nxt is not None:
            self._select_scene_in_list(nxt)
            self._load_as_current(nxt)
            return
        target_year = imagery_timeline.nearest_year_with_scenes(
            self.year_track, self.current_year, direction
        )
        if target_year is None:
            self.iface.messageBar().pushInfo(
                "Ferramentas Terra",
                "Não há aquisição {} disponível.".format(
                    "seguinte" if direction == 1 else "anterior"
                ),
            )
            return
        preview_scenes = imagery_timeline.scenes_for_year(self.scenes, target_year)
        if not preview_scenes:
            return
        edge_scene = preview_scenes[0] if direction == 1 else preview_scenes[-1]
        self._jump_to_year(target_year, scene_to_load=edge_scene)

    # ---------------------------------------------------------- metadados
    def _show_metadata(self, row):
        if row < 0 or row >= len(self.year_scenes):
            self.btn_load.setEnabled(False)
            self.meta_label.setText("Selecione uma aquisição na lista para ver os detalhes.")
            return
        scene = self.year_scenes[row]
        meta = stac_client.format_metadata(scene)
        coverage = stac_client.coverage_fraction(self._last_query_bbox, scene.get("bbox"))
        coverage_text = "{:.0f}%".format(coverage * 100) if coverage is not None else "Não informado"
        self.meta_label.setText(
            "Aquisição: {}\nPublicação do produto: {}\nSatélite/sensor: {}\n"
            "Resolução espacial: {}\nCobertura de nuvens: {}\nFonte: {}\n"
            "Identificador do produto: {}\nCobertura da área pesquisada: {}".format(
                meta["aquisicao"],
                meta["publicacao"],
                meta["satelite"],
                meta["resolucao"],
                meta["nuvens"],
                meta["fonte"],
                meta["id_produto"],
                coverage_text,
            )
        )
        self.btn_load.setEnabled(True)

    # -------------------------------------------------------------- carregar
    def _selected_scene(self):
        row = self.list_widget.currentRow()
        if row < 0 or row >= len(self.year_scenes):
            return None
        return self.year_scenes[row]

    def _load_selected(self):
        scene = self._selected_scene()
        if scene is None:
            return
        self._load_as_current(scene)

    def _set_busy(self, busy):
        if busy:
            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        else:
            QApplication.restoreOverrideCursor()

    def _load_as_current(self, scene):
        """Carrega `scene` como a imagem "principal" no mapa (fora dos
        slots de comparação A/B), sem nunca remover a imagem anterior
        antes de a nova ter sido validada, e preservando o enquadramento
        atual do canvas."""
        canvas = self.iface.mapCanvas()
        saved_extent = canvas.extent()

        self._set_busy(True)
        try:
            layer, error = imagery_bridge.load_scene(scene)
        finally:
            self._set_busy(False)

        if error:
            QMessageBox.warning(
                self,
                "Ferramentas Terra",
                "Não foi possível carregar esta aquisição:\n{}\n\n"
                "A última imagem válida (se houver) foi mantida.".format(error),
            )
            return

        old = self.current_layer
        if old is not None:
            try:
                QgsProject.instance().removeMapLayer(old.id())
            except Exception:
                pass
        self.current_layer = layer
        self.current_scene = scene

        canvas.setExtent(saved_extent)
        canvas.refresh()

        meta = stac_client.format_metadata(scene)
        coverage = stac_client.coverage_fraction(self._last_query_bbox, scene.get("bbox"))
        texto = "Mostrando: {} ({}), nuvens {}".format(meta["aquisicao"], meta["satelite"], meta["nuvens"])
        if coverage is not None and coverage < MIN_COVERAGE_TO_WARN:
            texto += " - cobre {:.0f}% da área visível pesquisada".format(coverage * 100)
        self.loaded_label.setText(texto)
        self.iface.messageBar().pushSuccess(
            "Ferramentas Terra", '"{}" carregada no mapa.'.format(layer.name())
        )

    def _load_into_slot(self, slot):
        scene = self._selected_scene()
        if scene is None:
            QMessageBox.information(
                self, "Ferramentas Terra", "Selecione uma aquisição na lista primeiro."
            )
            return
        canvas = self.iface.mapCanvas()
        saved_extent = canvas.extent()
        self._set_busy(True)
        try:
            layer, error = imagery_bridge.load_scene(scene)
        finally:
            self._set_busy(False)
        if error:
            QMessageBox.warning(self, "Ferramentas Terra", error)
            return
        old = self.slot_layers.get(slot)
        if old is not None:
            try:
                QgsProject.instance().removeMapLayer(old.id())
            except Exception:
                pass
        self.slot_layers[slot] = layer
        canvas.setExtent(saved_extent)
        canvas.refresh()
        meta = stac_client.format_metadata(scene)
        self.slot_status[slot].setText(meta["aquisicao"])
        self.slot_checks[slot].setEnabled(True)
        self.slot_checks[slot].setChecked(True)
        self.iface.messageBar().pushSuccess(
            "Ferramentas Terra", '"{}" carregada no slot de comparação.'.format(layer.name())
        )

    def _toggle_slot(self, slot, checked):
        layer = self.slot_layers.get(slot)
        if layer is None:
            return
        try:
            node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
            if node is not None:
                node.setItemVisibilityChecked(checked)
        except Exception:
            pass

    # ---------------------------------------------------------------- cache
    def _refresh_cache_label(self):
        size_kb = imagery_bridge.cache_size_bytes() / 1024.0
        self.cache_label.setText("Cache de busca: {:.1f} KB (só metadados, não imagens)".format(size_kb))

    def _do_clear_cache(self):
        removed = imagery_bridge.clear_cache()
        self._refresh_cache_label()
        self.iface.messageBar().pushInfo(
            "Ferramentas Terra", "{} arquivo(s) de cache removido(s).".format(removed)
        )

    # -------------------------------------------------------------- limpeza
    def closeEvent(self, event):
        if self.request is not None:
            self.request.cancel()
        super(ImageryDialog, self).closeEvent(event)
