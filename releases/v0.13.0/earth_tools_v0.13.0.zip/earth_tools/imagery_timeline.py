# -*- coding: utf-8 -*-
"""Linha do tempo anual de imagens de satélite (Fase F), sem depender do
PyQGIS - mesmo motivo de stac_client.py/imagery_cache.py: testável com
`python -m unittest` puro.

Separado de stac_client.py porque é uma camada de apresentação (como
agrupar/navegar cenas já encontradas), não de consulta/interpretação do
catálogo STAC. `scenes` em toda esta API é a lista de dicts já devolvida
por stac_client.parse_search_response.
"""

try:
    from . import stac_client
except ImportError:  # executado como modulo solto nos testes (sem pacote-pai)
    import stac_client


def _acquisition_year(scene):
    """Ano (int) da data de aquisição da cena, ou None se ausente/mal
    formada - nunca inventa um ano para uma cena sem data utilizável."""
    acquired = scene.get("acquired")
    if not acquired or len(acquired) < 4:
        return None
    try:
        return int(acquired[:4])
    except (TypeError, ValueError):
        return None


def years_in_range(start, end):
    """Todo ano entre start.year e end.year (inclusive), nessa ordem -
    inclusive dos anos sem nenhuma aquisição, para a trilha mostrar o
    período pesquisado inteiro sem fingir que é mais curto do que é."""
    if start is None or end is None or start.year > end.year:
        return []
    return list(range(start.year, end.year + 1))


def years_with_scenes(scenes):
    """Anos (int, ordenados) com pelo menos uma aquisição real."""
    years = {y for y in (_acquisition_year(s) for s in scenes) if y is not None}
    return sorted(years)


def build_year_track(start, end, scenes):
    """[{"year": int, "has_scenes": bool, "count": int}], um item por ano
    do período pesquisado - inclui também anos de cenas encontradas fora
    do intervalo nominal (não deveria acontecer, mas não esconde o dado se
    acontecer) e nunca marca como disponível um ano sem aquisição real."""
    counts = {}
    for scene in scenes:
        year = _acquisition_year(scene)
        if year is not None:
            counts[year] = counts.get(year, 0) + 1

    years = set(years_in_range(start, end))
    years.update(counts.keys())

    track = []
    for year in sorted(years):
        count = counts.get(year, 0)
        track.append({"year": year, "has_scenes": count > 0, "count": count})
    return track


def scenes_for_year(scenes, year):
    """Aquisições daquele ano, da mais antiga para a mais nova."""
    of_year = [s for s in scenes if _acquisition_year(s) == year]
    return stac_client.sort_by_acquisition(of_year, newest_first=False)


def nearest_year_with_scenes(year_track, from_year, direction):
    """Próximo ano com `has_scenes` True a partir de `from_year`, andando
    em `direction` (+1 = adiante, -1 = para trás) - pula por cima de anos
    sem dado em intervalos longos. None se não houver nenhum nessa
    direção."""
    if direction not in (1, -1):
        raise ValueError("direction precisa ser 1 ou -1")
    candidates = [
        entry["year"]
        for entry in year_track
        if entry["has_scenes"]
        and ((direction == 1 and entry["year"] > from_year) or (direction == -1 and entry["year"] < from_year))
    ]
    if not candidates:
        return None
    return min(candidates) if direction == 1 else max(candidates)


def adjacent_scene(scenes_of_year, current_id, direction):
    """Cena anterior/seguinte em `scenes_of_year` (já cronológica, ver
    scenes_for_year) a partir da cena de id `current_id`. None se
    `current_id` não estiver na lista ou se já for a ponta nessa direção -
    quem chamar decide se isso significa "ir para o ano vizinho"."""
    if direction not in (1, -1):
        raise ValueError("direction precisa ser 1 ou -1")
    index = None
    for i, scene in enumerate(scenes_of_year):
        if scene.get("id") == current_id:
            index = i
            break
    if index is None:
        return None
    new_index = index + direction
    if new_index < 0 or new_index >= len(scenes_of_year):
        return None
    return scenes_of_year[new_index]
