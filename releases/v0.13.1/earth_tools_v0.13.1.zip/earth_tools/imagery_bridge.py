# -*- coding: utf-8 -*-
"""Ponte entre stac_client.py (puro) e o QGIS: consulta assíncrona a um
catálogo STAC (não bloqueia o canvas), monta a composição RGB quando a
fonte não tem um asset único pronto (Landsat), carrega a cena escolhida
como camada raster, e mantém o cache de metadados em disco (Fase E).

Nada aqui toca no GeoPackage "Meus Lugares" nem em nenhuma geometria de
lugar - é só leitura de um serviço externo e criação de uma camada raster
nova no projeto, isolada de storage.py/places_model.py.
"""

import datetime as _dt
import hashlib
import json
import os
import tempfile

from qgis.core import (
    QgsContrastEnhancement,
    QgsProject,
    QgsRasterLayer,
    QgsRasterMinMaxOrigin,
)
from qgis.PyQt.QtCore import QByteArray, QObject, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest

from . import imagery_cache, stac_client, storage, utils

CACHE_DIR_NAME = "cache_imagens"


# -------------------------------------------------------------- cache local
def cache_dir():
    """Pasta local de cache de METADADOS (não imagens - ver
    imagery_cache.py), ao lado do GeoPackage "Meus Lugares" (mesmo critério
    de storage.gpkg_path: perto do projeto salvo, ou na pasta do usuário se
    o projeto ainda não foi salvo)."""
    base = os.path.dirname(storage.gpkg_path())
    path = os.path.join(base, CACHE_DIR_NAME)
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        pass
    return path


def _cache_file(key):
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return os.path.join(cache_dir(), digest + ".json")


def read_cache(provider_key, bbox, start, end):
    """[] cenas em cache se existirem e ainda não tiverem expirado (ver
    imagery_cache.DEFAULT_TTL_SECONDS); None se não houver nada
    aproveitável - força uma consulta nova."""
    key = imagery_cache.cache_key(provider_key, bbox, start, end)
    path = _cache_file(key)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        entry = {
            "cached_at": _dt.datetime.fromisoformat(data["cached_at"]),
            "scenes": data["scenes"],
        }
    except Exception:
        return None
    if not imagery_cache.should_use_cache(entry, _dt.datetime.now()):
        return None
    return entry["scenes"]


def write_cache(provider_key, bbox, start, end, scenes):
    key = imagery_cache.cache_key(provider_key, bbox, start, end)
    path = _cache_file(key)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"cached_at": _dt.datetime.now().isoformat(), "scenes": scenes}, f)
    except Exception as exc:
        utils.log("Falha ao gravar cache de busca de imagens: {}".format(exc), "warning")


def clear_cache():
    """Apaga só os arquivos de metadados em cache_dir(); nunca toca no
    GeoPackage nem em nenhuma camada já carregada no projeto. Devolve
    quantos arquivos foram removidos."""
    removed = 0
    directory = cache_dir()
    try:
        for name in os.listdir(directory):
            if name.endswith(".json"):
                try:
                    os.remove(os.path.join(directory, name))
                    removed += 1
                except OSError:
                    pass
    except OSError:
        pass
    return removed


def cache_size_bytes():
    total = 0
    directory = cache_dir()
    try:
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                total += os.path.getsize(path)
    except OSError:
        pass
    return total


# ---------------------------------------------------------------- consulta
PAGE_LIMIT = 100  # itens por pagina - confirmado que o servico aceita este tamanho
MAX_PAGES = 10  # teto de seguranca: no maximo 1000 cenas por busca (nunca pagina sem fim)


class SearchRequest(QObject):
    """Consulta assíncrona a um catálogo STAC - usa QNetworkAccessManager
    (E/S de rede do próprio Qt/QGIS, que respeita a configuração de proxy
    do QGIS), nunca bloqueia o laço de eventos: o canvas continua
    respondendo enquanto a resposta não chega. Cancelável via cancel().

    Pagina automaticamente (até MAX_PAGES) seguindo o token de "próxima
    página" da resposta - confirmado contra o serviço real que uma busca
    de vários anos tem muito mais do que uma página de resultados (uma
    área rural típica tem ~300 cenas de Landsat em 5 anos); sem paginar,
    só a primeira página (as cenas mais recentes) chegava ao usuário, e a
    linha do tempo parecia só ter aquisição no ano atual.

    Cada busca nova (dlg_imagery._do_search) cria uma instância própria -
    quem mantém a instância anterior viva por engano é responsabilidade de
    quem a usa; por isso o diálogo cancela E desconecta o `finished` da
    instância anterior antes de criar uma nova (ver ImageryDialog._do_search),
    para uma resposta atrasada da busca velha nunca sobrescrever a lista de
    uma busca mais nova.
    """

    finished = pyqtSignal(list, str)  # scenes, mensagem_de_erro ("" = sem erro/cancelado)

    def __init__(self, parent=None):
        super(SearchRequest, self).__init__(parent)
        self._manager = QNetworkAccessManager(self)
        self._reply = None
        self._provider_key = None
        self._bbox = None
        self._start = None
        self._end = None
        self._page_limit = PAGE_LIMIT
        self._accumulated = []
        self._pages_fetched = 0

    def start(self, provider_key, bbox, start, end, limit=PAGE_LIMIT, use_cache=True):
        if use_cache:
            cached = read_cache(provider_key, bbox, start, end)
            if cached is not None:
                self.finished.emit(cached, "")
                return
        self._provider_key = provider_key
        self._bbox, self._start, self._end = bbox, start, end
        self._page_limit = limit
        self._accumulated = []
        self._pages_fetched = 0
        self._request_page(None)

    def _request_page(self, next_token):
        try:
            body = stac_client.build_search_body(
                self._provider_key, self._bbox, self._start, self._end,
                limit=self._page_limit, next_token=next_token,
            )
        except stac_client.StacQueryError as exc:
            self.finished.emit([], str(exc))
            return
        request = QNetworkRequest(QUrl(stac_client.STAC_ENDPOINT))
        request.setHeader(QNetworkRequest.ContentTypeHeader, b"application/json")
        payload = QByteArray(json.dumps(body).encode("utf-8"))
        self._reply = self._manager.post(request, payload)
        self._reply.finished.connect(self._on_page_finished)

    def cancel(self):
        if self._reply is not None:
            self._reply.abort()

    def _on_page_finished(self):
        reply = self._reply
        self._reply = None
        if reply is None:
            return
        try:
            if reply.error() != QNetworkReply.NoError:
                if reply.error() == QNetworkReply.OperationCanceledError:
                    self.finished.emit([], "")  # cancelado pelo usuario: nao e um erro a mostrar
                    return
                status = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
                body_text = bytes(reply.readAll()).decode("utf-8", "ignore")
                message = stac_client.classify_http_error(status, body_text)
                utils.log("Falha na consulta de imagens: {}".format(message), "warning")
                self.finished.emit([], message)
                return

            raw = bytes(reply.readAll()).decode("utf-8", "ignore")
            try:
                data = json.loads(raw)
            except Exception as exc:
                self.finished.emit(
                    [], "A resposta do serviço de imagens não é um JSON válido: {}".format(exc)
                )
                return
            try:
                scenes = stac_client.parse_search_response(data, self._provider_key)
            except stac_client.StacResponseError as exc:
                utils.log("Resposta STAC com formato inesperado: {}".format(exc), "critical")
                self.finished.emit([], str(exc))
                return

            self._accumulated.extend(scenes)
            self._pages_fetched += 1

            if stac_client.should_fetch_next_page(
                data, self._page_limit, self._pages_fetched, MAX_PAGES
            ):
                self._request_page(stac_client.extract_next_token(data))
                return

            if self._pages_fetched >= MAX_PAGES:
                utils.log(
                    "Busca de imagens interrompida apos {} paginas ({} por pagina) - pode "
                    "haver mais aquisicoes no periodo pesquisado do que as mostradas.".format(
                        MAX_PAGES, self._page_limit
                    ),
                    "warning",
                )

            final_scenes = stac_client.dedupe_scenes(self._accumulated)
            write_cache(self._provider_key, self._bbox, self._start, self._end, final_scenes)
            self.finished.emit(final_scenes, "")
        finally:
            reply.deleteLater()


# --------------------------------------------------------- carregar no mapa
SCENE_ID_PROPERTY = "ferramentas_terra_scene_id"


def build_band_vrt(hrefs_rgb, name_hint="cena"):
    """3 bandas remotas (red, green, blue) -> um VRT local empilhando-as
    como composição RGB. Usa gdal.BuildVRT (não XML escrito à mão: um VRT
    precisa do tamanho/georreferenciamento certos, que só se sabe lendo o
    cabeçalho de cada banda). O GDAL lê esse cabeçalho via /vsicurl/ (poucos
    KB, não o arquivo inteiro); os pixels só são buscados de fato quando o
    QGIS desenha a tela.

    VRTNodata="0" declara explicitamente o preenchimento/sem-cobertura
    (valor 0 nas bandas de reflectância de superfície do Sentinel-2/
    Landsat Coleção 2) como NoData - sem isso, esses pixels de fundo
    entram nas estatísticas de realce de contraste e empurram a imagem
    toda para um cinza lavado (causa raiz da "imagem cinza" com bandas
    brutas, distinta do asset "visual" já pronto em 8 bits)."""
    try:
        from osgeo import gdal
    except Exception as exc:
        raise IOError("módulo GDAL (osgeo) indisponível: {}".format(exc))

    vsicurl_paths = ["/vsicurl/{}".format(href) for href in hrefs_rgb]
    fd, path = tempfile.mkstemp(prefix="ferramentas_terra_{}_".format(name_hint), suffix=".vrt")
    os.close(fd)
    try:
        gdal.UseExceptions()
        options = gdal.BuildVRTOptions(separate=True, VRTNodata="0")
        ds = gdal.BuildVRT(path, vsicurl_paths, options=options)
        if ds is None:
            raise IOError("gdal.BuildVRT não devolveu um dataset")
        ds.FlushCache()
        ds = None
    except Exception:
        try:
            os.remove(path)
        except OSError:
            pass
        raise
    return path


def _apply_band_stretch(layer):
    """Realce de contraste por corte cumulativo 2%-98% (o mesmo que
    Propriedades > Estilo > Cortar valores min/máx > Corte cumulativo de
    contagem faria manualmente), aplicado explicitamente em vez de confiar
    no QSettings global do QGIS - para a composição de bandas brutas
    (Landsat, ou Sentinel-2 sem asset "visual") não depender de que o
    usuário tenha esse padrão configurado, e não ficar sujeita a uma
    amostragem de estatística que inclua os pixels de NoData."""
    try:
        layer.setContrastEnhancement(
            QgsContrastEnhancement.StretchToMinimumMaximum,
            QgsRasterMinMaxOrigin.CumulativeCut,
        )
    except Exception as exc:
        utils.log("Falha ao aplicar realce de contraste na imagem: {}".format(exc), "warning")


def load_scene(scene):
    """Carrega a cena escolhida como camada raster no projeto. Nunca toca
    em geometrias/GeoPackage de lugares - cria só uma QgsRasterLayer nova.
    Devolve (layer, erro): layer é None e erro vem preenchido se não for
    possível carregar. A camada devolvida tem a cobertura da área
    pesquisada (quando bbox for informado) e o id da cena como propriedade
    customizada (SCENE_ID_PROPERTY), para confirmar que a imagem carregada
    corresponde à aquisição escolhida.

    Confere de novo, aqui, que a `collection` da cena é a esperada para o
    `provider` dela antes de tentar montar qualquer composição RGB -
    defesa em profundidade: stac_client.parse_search_response já descarta
    isso na busca, mas um objeto `scene` pode chegar até aqui por outro
    caminho (ex.: reaproveitado de uma lista antiga guardada em memória) -
    nunca tenta carregar um produto de sensor diferente do esperado (ex.:
    Sentinel-1/radar) como se fosse uma composição óptica RGB."""
    provider_info = stac_client.PROVIDERS.get(scene.get("provider"))
    scene_collection = scene.get("collection")
    if provider_info is None:
        return None, "Fonte de imagem desconhecida para esta cena."
    if scene_collection and scene_collection != provider_info["collection"]:
        utils.log(
            "load_scene recusou a cena {}: coleção '{}' não é a esperada para o "
            "provedor '{}' ('{}').".format(
                scene.get("id"), scene_collection, scene.get("provider"), provider_info["collection"]
            ),
            "critical",
        )
        return None, (
            "Esta cena pertence a outra coleção/sensor ({}), diferente do esperado "
            "para esta fonte - não é uma composição óptica RGB válida.".format(scene_collection)
        )

    kind, payload = stac_client.true_color_source(scene)
    meta = stac_client.format_metadata(scene)
    acquired_date = meta["aquisicao"][:10] if meta["aquisicao"] != "Não informado" else "?"
    name = "{} - {} (nuvens {})".format(meta["fonte"], acquired_date, meta["nuvens"])

    needs_stretch = False
    if kind == "cog":
        uri = "/vsicurl/{}".format(payload)
    elif kind == "bands":
        try:
            uri = build_band_vrt(payload, name_hint=scene.get("id", "cena"))
        except Exception as exc:
            utils.log("Falha ao montar VRT de bandas: {}".format(exc), "critical")
            return None, "Não foi possível montar a composição de bandas:\n{}".format(exc)
        needs_stretch = True
    else:
        return None, "Esta cena não tem bandas RGB suficientes para carregar."

    try:
        layer = QgsRasterLayer(uri, name)
    except Exception as exc:
        utils.log("Falha ao abrir camada de imagem: {}".format(exc), "critical")
        return None, "Não foi possível abrir a imagem:\n{}".format(exc)

    if not layer.isValid():
        utils.log("QgsRasterLayer inválida para a cena {}: {}".format(scene.get("id"), uri), "critical")
        return None, (
            "A imagem não pôde ser aberta - o arquivo remoto pode estar indisponível "
            "agora, ou a conexão falhou no meio da leitura."
        )

    if needs_stretch:
        _apply_band_stretch(layer)
    layer.setCustomProperty(SCENE_ID_PROPERTY, scene.get("id") or "")

    QgsProject.instance().addMapLayer(layer)
    return layer, None
