# -*- coding: utf-8 -*-
"""Regra pura de cache de METADADOS de busca de imagens (Fase E), sem
depender do PyQGIS.

Decisão deliberada: só os resultados de busca (JSON pequeno - id, datas,
nuvens, endereços dos arquivos) são cacheados, nunca os pixels das
imagens. Os COGs de satélite têm centenas de MB; cacheá-los exigiria
gerenciar um armazenamento sem limite claro, e o próprio GDAL já faz
cache de blocos por requisição de intervalo (range request) durante a
sessão via /vsicurl/, então duplicar isso aqui não traria benefício real
- so risco de armazenar uma imagem inteira "para sempre" sem o usuário
saber. Ver imagery_bridge.py para onde esta política é de fato aplicada
(leitura/escrita em disco).
"""

DEFAULT_TTL_SECONDS = 6 * 3600
# 6 horas: cenas novas do Sentinel-2 chegam a cada ~5 dias para o mesmo
# ponto; não há razão para reconsultar a mesma área/período toda hora
# dentro da mesma sessão de trabalho, mas também não se quer um cache tão
# longo que esconda aquisições realmente novas por dias.

CACHE_SCHEMA_VERSION = 2
# Bump sempre que o FORMATO ou a COMPLETUDE do resultado cacheado mudar -
# muda a chave e invalida na hora qualquer arquivo de cache já gravado no
# disco do usuário, sem precisar apagá-lo manualmente (o TTL de 6h não
# ajudaria aqui: um arquivo gravado por uma versão antiga e lido dentro do
# prazo continuaria sendo servido como se fosse válido).
# v2 (Fase F): corrige a paginação da busca (versões anteriores só
# traziam a primeira página - no máximo as ~30 cenas mais recentes -, por
# isso só o ano mais recente aparecia disponível na linha do tempo) e
# passa a descartar cenas de uma coleção diferente da pedida antes de
# gravar no cache (ver stac_client._parse_feature).


def cache_key(provider_key, bbox, start, end):
    """Chave estável para uma consulta. A área é arredondada a 3 casas
    decimais (~100 m) para pequenas variações de enquadramento do mapa
    não gerarem uma chave nova a cada consulta na prática."""
    rounded = tuple(round(float(v), 3) for v in bbox)
    return "v{}|{}|{}|{}|{}".format(
        CACHE_SCHEMA_VERSION, provider_key, rounded, start.isoformat(), end.isoformat()
    )


def is_expired(cached_at, now, ttl_seconds=DEFAULT_TTL_SECONDS):
    """cached_at/now: datetime.datetime, nos mesmos termos (aware ou
    naive) - comparar um aware com um naive levanta TypeError de
    propósito, para não comparar silenciosamente horários incompatíveis."""
    age = (now - cached_at).total_seconds()
    return age > ttl_seconds


def should_use_cache(entry, now, ttl_seconds=DEFAULT_TTL_SECONDS):
    """entry: {"cached_at": datetime, "scenes": [...]} ou None/{}.
    Devolve True só se existir e não estiver expirado."""
    if not entry or "cached_at" not in entry:
        return False
    return not is_expired(entry["cached_at"], now, ttl_seconds)
