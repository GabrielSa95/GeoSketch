# -*- coding: utf-8 -*-
"""Conversões de unidade, medição elipsoidal e formatação de coordenadas."""

import math
import re

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsUnitTypes,
)

from . import measure_rules

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")

LOG_LEVELS = {"info": 0, "warning": 1, "critical": 2}


def log(message, level="warning"):
    """Grava no painel nativo "Mensagens de registro" do QGIS (Ver > Paineis).

    Complementa os avisos de messageBar/QMessageBox: aqueles desaparecem ou
    exigem que alguem esteja olhando a tela no momento da falha; isto aqui
    fica registrado para diagnostico posterior, sem precisar de um arquivo
    de log proprio do plugin.
    """
    try:
        from qgis.core import Qgis, QgsMessageLog

        levels = {
            "info": Qgis.Info,
            "warning": Qgis.Warning,
            "critical": Qgis.Critical,
        }
        QgsMessageLog.logMessage(
            str(message), "Ferramentas Terra", levels.get(level, Qgis.Warning)
        )
    except Exception:
        pass


def zoom_to_layer(iface, layer):
    """Amplia o mapa até aquela camada usando o zoom nativo do QGIS, que já
    trata bem o caso de uma feição pontual (extensão zero), aplicando um
    buffer razoável em vez de tentar ampliar ao infinito."""
    try:
        iface.setActiveLayer(layer)
        iface.actionZoomToLayer().trigger()
    except Exception:
        pass


# ---------------------------------------------------------------- unidades
# Cada item: (rótulo, fator em relação à unidade base do SI)
# Comprimento: fator converte METROS -> unidade.
LENGTH_UNITS = [
    ("Metros", 1.0),
    ("Quilômetros", 0.001),
    ("Centímetros", 100.0),
    ("Pés", 3.280839895013123),
    ("Jardas", 1.093613298337708),
    ("Milhas", 0.0006213711922373339),
    ("Milhas náuticas", 0.0005399568034557235),
]

# Área: fator converte METROS QUADRADOS -> unidade.
# Alqueire paulista = 24.200 m²; alqueire mineiro (geométrico) = 48.400 m².
AREA_UNITS = [
    ("Metros quadrados", 1.0),
    ("Hectares", 0.0001),
    ("Quilômetros quadrados", 0.000001),
    ("Alqueire paulista", 1.0 / 24200.0),
    ("Alqueire mineiro", 1.0 / 48400.0),
    ("Acres", 0.0002471053814671653),
    ("Pés quadrados", 10.76391041670972),
]

DEFAULT_LENGTH = "Metros"
DEFAULT_AREA = "Hectares"


def convert_length(meters, label):
    for name, factor in LENGTH_UNITS:
        if name == label:
            return meters * factor
    return meters


def to_meters(value, label):
    """Inverso de convert_length: `value` na unidade `label` -> metros."""
    return measure_rules.to_meters(value, label, LENGTH_UNITS)


def convert_area(square_meters, label):
    for name, factor in AREA_UNITS:
        if name == label:
            return square_meters * factor
    return square_meters


def format_number(value):
    """Formata no padrão brasileiro: milhar com ponto, decimal com vírgula."""
    if value is None:
        return "0,00"
    if abs(value) >= 1000:
        text = "{:,.2f}".format(value)
    else:
        text = "{:.2f}".format(value)
    return text.replace(",", "\x00").replace(".", ",").replace("\x00", ".")


# --------------------------------------------------------------- medição
def make_distance_area(crs=None):
    """QgsDistanceArea configurado para medir sobre o elipsoide WGS84.

    Forçamos o elipsoide em vez de herdar do projeto porque muitos projetos
    vêm com elipsoide 'NONE', o que faria a medição virar cartesiana e dar
    resultados errados em graus decimais.
    """
    da = QgsDistanceArea()
    src = crs if crs is not None else QgsProject.instance().crs()
    da.setSourceCrs(src, QgsProject.instance().transformContext())
    da.setEllipsoid("WGS84")
    return da


def measure_length(points, crs=None):
    """Comprimento em metros de uma lista de QgsPointXY."""
    if not points or len(points) < 2:
        return 0.0
    da = make_distance_area(crs)
    try:
        return float(da.measureLine(points))
    except Exception:
        return 0.0


def measure_area(points, crs=None):
    """Área em metros quadrados do anel formado pelos pontos."""
    if not points or len(points) < 3:
        return 0.0
    da = make_distance_area(crs)
    ring = list(points)
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    try:
        return float(da.measureArea(QgsGeometry.fromPolygonXY([ring])))
    except Exception:
        return 0.0


def measure_perimeter(points, crs=None):
    """Perímetro em metros (fecha o anel automaticamente)."""
    if not points or len(points) < 3:
        return measure_length(points, crs)
    ring = list(points)
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    return measure_length(ring, crs)


def project_point(start, distance_m, azimuth_deg, crs=None):
    """Ponto a `distance_m` metros de `start`, no azimute `azimuth_deg`.

    Convenção do azimute: graus a partir do Norte geográfico, sentido
    horário - a MESMA já usada no rumo da aba Linha da Régua
    (dlg_ruler.py._bearing_text) e em circle_points, abaixo. `start` e o
    ponto devolvido estão no mesmo SRC (o de `crs`, ou o do projeto se
    omitido) - QgsDistanceArea faz o cálculo geodésico sobre o elipsoide
    WGS84 por baixo dos panos e transforma de volta, então o resultado é
    correto tanto em SRC geográfico (graus) quanto projetado (metros),
    exatamente como já acontece com o círculo e com as outras medições do
    plugin. Devolve None se o cálculo falhar (ex.: SRC inválido).
    """
    da = make_distance_area(crs)
    azimuth = measure_rules.normalize_azimuth(azimuth_deg)
    try:
        p = da.computeSpheroidProject(start, distance_m, math.radians(azimuth))
        return QgsPointXY(p)
    except Exception:
        return None


def circle_points(center, edge, segments=72, crs=None):
    """Gera o anel de um círculo geodésico a partir do centro e de um ponto da borda.

    `crs` precisa ser o CRS em que `center`/`edge` já estão expressos (o
    CRS do canvas/mapa) - sem isso, `make_distance_area()` cai por omissão
    no CRS do PROJETO, que já causou o círculo "desenhar só o raio" quando
    a projeção lançava erro num segmento: o anel inteiro era descartado
    (`return [], radius`), e quem chama (maptools.display_points()) caía de
    volta para desenhar [centro, borda] como "polígono" - visualmente igual
    à linha pontilhada do raio, nunca a circunferência completa. Agora cada
    segmento é tentado de forma independente: uma falha isolada não derruba
    o anel inteiro, e só desistimos (devolvendo anel vazio) se sobrarem
    menos de 3 pontos utilizáveis - nesse caso extremo, quem chama não deve
    fingir que há um círculo para desenhar.
    """
    da = make_distance_area(crs)
    try:
        radius = da.measureLine(center, edge)
    except Exception:
        radius = 0.0
    if radius <= 0:
        return [], 0.0
    pts = []
    for i in range(segments):
        azimuth = (360.0 / segments) * i
        try:
            p = da.computeSpheroidProject(center, radius, math.radians(azimuth))
            pts.append(QgsPointXY(p))
        except Exception as exc:
            log(
                "circle_points: falha ao projetar o segmento {} de {} (azimute {:.1f}°): "
                "{}".format(i, segments, azimuth, exc),
                "warning",
            )
    if len(pts) < 3:
        if pts:
            log(
                "circle_points: anel descartado - só {} de {} segmentos foram "
                "projetados com sucesso.".format(len(pts), segments),
                "warning",
            )
        return [], radius
    pts.append(pts[0])
    return pts, radius


# ---------------------------------------------------- coordenadas / DMS
def to_wgs84(point, source_crs):
    """Converte um QgsPointXY para latitude/longitude WGS84."""
    if source_crs == WGS84:
        return QgsPointXY(point)
    tr = QgsCoordinateTransform(source_crs, WGS84, QgsProject.instance())
    return tr.transform(point)


def from_wgs84(point, target_crs):
    if target_crs == WGS84:
        return QgsPointXY(point)
    tr = QgsCoordinateTransform(WGS84, target_crs, QgsProject.instance())
    return tr.transform(point)


def format_dm(value, is_latitude):
    """Formata em grau + minuto decimal, como o Google Earth: 23° 34.616'S."""
    if is_latitude:
        hemi = "S" if value < 0 else "N"
    else:
        hemi = "O" if value < 0 else "L"
    value = abs(value)
    degrees = int(value)
    minutes = (value - degrees) * 60.0
    return "{}° {:.3f}'{}".format(degrees, minutes, hemi)


_DM_RE = re.compile(
    r"^\s*(-?\d+(?:[.,]\d+)?)\s*[°º]?\s*"
    r"(?:(\d+(?:[.,]\d+)?)\s*['′]?\s*)?"
    r"(?:(\d+(?:[.,]\d+)?)\s*[\"″]?\s*)?"
    r"([NSELWOnselwo])?\s*$"
)


def parse_coordinate(text):
    """Aceita '23.5769', '-23,5769', \"23° 34.616'S\" ou \"23 34 37 S\".

    Devolve float em graus decimais ou None se não conseguir interpretar.
    """
    if text is None:
        return None
    match = _DM_RE.match(str(text).strip())
    if not match:
        return None
    deg_txt, min_txt, sec_txt, hemi = match.groups()
    try:
        value = abs(float(deg_txt.replace(",", ".")))
        negative = deg_txt.strip().startswith("-")
        if min_txt:
            value += float(min_txt.replace(",", ".")) / 60.0
        if sec_txt:
            value += float(sec_txt.replace(",", ".")) / 3600.0
    except (TypeError, ValueError):
        return None
    if hemi and hemi.upper() in ("S", "W", "O"):
        negative = True
    return -value if negative else value


def string_to_color(text, fallback=(255, 255, 0, 255)):
    """'r,g,b,a' -> QColor. Usado para recarregar o estilo na janela de edicao."""
    from qgis.PyQt.QtGui import QColor

    try:
        parts = [int(p) for p in str(text).split(",")]
        if len(parts) == 3:
            parts.append(255)
        return QColor(*parts[:4])
    except Exception:
        return QColor(*fallback)


def color_to_string(qcolor):
    """QColor -> 'r,g,b,a' (formato que o QGIS lê em propriedades definidas por dados)."""
    return "{},{},{},{}".format(
        qcolor.red(), qcolor.green(), qcolor.blue(), qcolor.alpha()
    )
