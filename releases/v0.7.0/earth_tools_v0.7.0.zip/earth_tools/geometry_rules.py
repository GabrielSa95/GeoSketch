# -*- coding: utf-8 -*-
"""Regras puras de contagem de vertices, sem depender do PyQGIS.

Isoladas aqui para serem usadas tanto no desenho (maptools.py) quanto na
edicao de feicoes existentes (vertexedit.py), e para poderem ser testadas sem
precisar do ambiente do QGIS. So dependem de == / != entre pontos, entao
funcionam com QgsPointXY ou qualquer outro objeto comparavel por valor.
"""


def unique_count(points):
    """Quantidade de vertices distintos, ignorando repeticoes consecutivas."""
    count = 0
    prev = None
    for point in points:
        if prev is None or point != prev:
            count += 1
        prev = point
    return count


def dedup_consecutive(points):
    """Remove vertices repetidos que aparecem um atras do outro."""
    result = []
    for point in points:
        if not result or point != result[-1]:
            result.append(point)
    return result


def can_remove_vertex(points, index, minimum):
    """True se apagar points[index] ainda deixa vertices distintos suficientes."""
    if not (0 <= index < len(points)):
        return False
    candidate = list(points)
    candidate.pop(index)
    return unique_count(candidate) >= minimum
