# -*- coding: utf-8 -*-
"""Widgets reutilizados pelas janelas, no mesmo layout do Google Earth."""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from . import utils


class ColorButton(QPushButton):
    """Botão quadrado que abre o seletor de cor, como o do Google Earth."""

    colorChanged = pyqtSignal(QColor)

    def __init__(self, color=QColor(255, 255, 0), parent=None):
        super(ColorButton, self).__init__(parent)
        self._color = QColor(color)
        self.setFixedSize(28, 22)
        self.clicked.connect(self._pick)
        self._paint()

    def _paint(self):
        self.setStyleSheet(
            "background-color: rgb({},{},{}); border: 1px solid #808080;".format(
                self._color.red(), self._color.green(), self._color.blue()
            )
        )

    def _pick(self):
        chosen = QColorDialog.getColor(self._color, self, "Escolher cor")
        if chosen.isValid():
            self._color = chosen
            self._paint()
            self.colorChanged.emit(chosen)

    def color(self):
        return QColor(self._color)

    def setColor(self, color):
        self._color = QColor(color)
        self._paint()
        self.colorChanged.emit(self._color)


class StyleTab(QWidget):
    """Aba Estilo/Cor: cor, largura e opacidade da linha e do preenchimento."""

    changed = pyqtSignal()

    def __init__(self, with_fill=True, with_width=True, parent=None):
        super(StyleTab, self).__init__(parent)
        self.with_fill = with_fill
        layout = QVBoxLayout(self)

        line_box = QGroupBox("Linhas")
        line_form = QHBoxLayout(line_box)
        line_form.addWidget(QLabel("Cor:"))
        self.line_color = ColorButton(QColor(255, 255, 0))
        line_form.addWidget(self.line_color)
        if with_width:
            line_form.addSpacing(12)
            line_form.addWidget(QLabel("Largura:"))
            self.line_width = QDoubleSpinBox()
            self.line_width.setRange(0.1, 20.0)
            self.line_width.setSingleStep(0.1)
            self.line_width.setValue(1.0)
            self.line_width.setDecimals(1)
            self.line_width.setFixedWidth(70)
            line_form.addWidget(self.line_width)
        else:
            self.line_width = None
        line_form.addSpacing(12)
        line_form.addWidget(QLabel("Opacidade:"))
        self.line_opacity = QSpinBox()
        self.line_opacity.setRange(0, 100)
        self.line_opacity.setValue(100)
        self.line_opacity.setSuffix("%")
        self.line_opacity.setFixedWidth(70)
        line_form.addWidget(self.line_opacity)
        line_form.addStretch()
        layout.addWidget(line_box)

        if with_fill:
            fill_box = QGroupBox("Área")
            fill_form = QHBoxLayout(fill_box)
            fill_form.addWidget(QLabel("Cor:"))
            self.fill_color = ColorButton(QColor(255, 255, 255))
            fill_form.addWidget(self.fill_color)
            fill_form.addSpacing(12)
            self.fill_mode = QComboBox()
            self.fill_mode.addItems(["Preenchido", "Circunscrito", "Preenchido + contorno"])
            self.fill_mode.setCurrentIndex(2)
            self.fill_mode.setFixedWidth(150)
            fill_form.addWidget(self.fill_mode)
            fill_form.addSpacing(12)
            fill_form.addWidget(QLabel("Opacidade:"))
            self.fill_opacity = QSpinBox()
            self.fill_opacity.setRange(0, 100)
            self.fill_opacity.setValue(35)
            self.fill_opacity.setSuffix("%")
            self.fill_opacity.setFixedWidth(70)
            fill_form.addWidget(self.fill_opacity)
            fill_form.addStretch()
            layout.addWidget(fill_box)
        else:
            self.fill_color = None
            self.fill_mode = None
            self.fill_opacity = None

        layout.addStretch()

        for widget in (self.line_color, self.fill_color):
            if widget is not None:
                widget.colorChanged.connect(self.changed)
        for widget in (self.line_width, self.line_opacity, self.fill_opacity):
            if widget is not None:
                widget.valueChanged.connect(self.changed)
        if self.fill_mode is not None:
            self.fill_mode.currentIndexChanged.connect(self.changed)

    # ------------------------------------------------------------ leitura
    def line_color_string(self):
        color = self.line_color.color()
        color.setAlpha(int(self.line_opacity.value() * 2.55))
        return utils.color_to_string(color)

    def fill_color_string(self):
        if self.fill_color is None:
            return "255,255,255,90"
        color = self.fill_color.color()
        alpha = self.fill_opacity.value()
        if self.fill_mode is not None and self.fill_mode.currentIndex() == 1:
            alpha = 0  # "Circunscrito" = só contorno
        color.setAlpha(int(alpha * 2.55))
        return utils.color_to_string(color)

    def line_width_value(self):
        return float(self.line_width.value()) if self.line_width else 1.0

    def load_values(self, line_color, fill_color, line_width):
        """Preenche a aba com o estilo atual de um lugar ja criado."""
        line = utils.string_to_color(line_color)
        self.line_color.setColor(QColor(line.red(), line.green(), line.blue()))
        self.line_opacity.setValue(int(round(line.alpha() / 2.55)))
        if self.line_width is not None:
            try:
                self.line_width.setValue(float(line_width))
            except (TypeError, ValueError):
                pass
        if self.fill_color is not None:
            fill = utils.string_to_color(fill_color, (255, 255, 255, 90))
            self.fill_color.setColor(QColor(fill.red(), fill.green(), fill.blue()))
            self.fill_opacity.setValue(int(round(fill.alpha() / 2.55)))
            if self.fill_mode is not None:
                self.fill_mode.setCurrentIndex(1 if fill.alpha() == 0 else 2)


class DescriptionTab(QWidget):
    """Aba Descrição, com os botões de inserir link e imagem."""

    def __init__(self, parent=None):
        super(DescriptionTab, self).__init__(parent)
        layout = QVBoxLayout(self)

        buttons = QHBoxLayout()
        self.btn_link = QPushButton("Adicionar link…")
        self.btn_web_image = QPushButton("Adicionar imagem da Web…")
        self.btn_local_image = QPushButton("Adicionar imagem local…")
        for btn in (self.btn_link, self.btn_web_image, self.btn_local_image):
            buttons.addWidget(btn)
        buttons.addStretch()
        layout.addLayout(buttons)

        self.editor = QPlainTextEdit()
        self.editor.setTabChangesFocus(True)
        layout.addWidget(self.editor)

        self.btn_link.clicked.connect(self._insert_link)
        self.btn_web_image.clicked.connect(self._insert_web_image)
        self.btn_local_image.clicked.connect(self._insert_local_image)

    def _insert_link(self):
        from qgis.PyQt.QtWidgets import QInputDialog

        url, ok = QInputDialog.getText(self, "Adicionar link", "Endereço (URL):")
        if ok and url:
            self.editor.insertPlainText('<a href="{0}">{0}</a>'.format(url))

    def _insert_web_image(self):
        from qgis.PyQt.QtWidgets import QInputDialog

        url, ok = QInputDialog.getText(self, "Imagem da Web", "Endereço da imagem:")
        if ok and url:
            self.editor.insertPlainText('<img src="{}" width="400"/>'.format(url))

    def _insert_local_image(self):
        from qgis.PyQt.QtWidgets import QFileDialog

        path, _ = QFileDialog.getOpenFileName(
            self, "Escolher imagem", "", "Imagens (*.png *.jpg *.jpeg *.gif *.bmp)"
        )
        if path:
            self.editor.insertPlainText('<img src="file:///{}" width="400"/>'.format(path))

    def text(self):
        return self.editor.toPlainText()

    def setText(self, value):
        self.editor.setPlainText(value or "")


class UnitRow(QWidget):
    """Linha 'rótulo .... valor [unidade]', igual às da Régua."""

    unitChanged = pyqtSignal()

    def __init__(self, label, units, default, parent=None):
        super(UnitRow, self).__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(QLabel(label))
        layout.addStretch()
        self.value = QLabel("0,00")
        self.value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.value.setMinimumWidth(140)
        layout.addWidget(self.value)
        self.combo = QComboBox()
        self.combo.addItems([name for name, _ in units])
        index = self.combo.findText(default)
        if index >= 0:
            self.combo.setCurrentIndex(index)
        self.combo.setMinimumWidth(190)
        layout.addWidget(self.combo)
        self.combo.currentIndexChanged.connect(self.unitChanged)

    def unit(self):
        return self.combo.currentText()

    def setValue(self, text):
        self.value.setText(text)
