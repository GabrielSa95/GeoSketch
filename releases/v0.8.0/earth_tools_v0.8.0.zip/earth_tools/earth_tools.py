# -*- coding: utf-8 -*-
"""Barra de ferramentas principal e instalacao do menu de contexto."""

import os
import webbrowser

from qgis.core import QgsProject
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from . import storage
from .dlg_edit import EditDialog
from .dlg_feature import FeatureDialog
from .dlg_goto import GotoDialog
from .dlg_ruler import RulerDialog
from .layeractions import LayerActions

PLUGIN_DIR = os.path.dirname(__file__)


def icon(name):
    return QIcon(os.path.join(PLUGIN_DIR, "icons", name))


class EarthTools(object):
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.toolbar = None
        self._dialogs = []
        self._layer_actions = None
        self._vertex_tool = None
        self._fullscreen_action = None

    # -------------------------------------------------------------- ciclo
    def initGui(self):
        self.toolbar = self.iface.addToolBar("Ferramentas Terra")
        self.toolbar.setObjectName("FerramentasTerra")

        self._add("placemark.svg", "Adicionar marcador de local",
                  lambda: self.open_feature("point"))
        self._add("polygon.svg", "Adicionar poligono",
                  lambda: self.open_feature("polygon"))
        self._add("path.svg", "Adicionar caminho",
                  lambda: self.open_feature("line"))
        self.toolbar.addSeparator()
        self._add("ruler.svg", "Regua", self._open_ruler)
        self.toolbar.addSeparator()
        self._add("folder.svg", "Nova pasta", self._new_group)
        self._add("maps.svg", "Ver no Google Maps", self._open_google_maps)
        self.toolbar.addSeparator()
        self._add("goto.svg", "Ir para coordenadas", self._open_goto)
        self._add_fullscreen_toggle()

        self._layer_actions = LayerActions(self.iface, self)
        self._layer_actions.install()

    def unload(self):
        if self._layer_actions is not None:
            self._layer_actions.uninstall()
            self._layer_actions = None
        for dialog in list(self._dialogs):
            try:
                dialog.close()
            except Exception:
                pass
        self._dialogs = []
        for action in self.actions:
            self.iface.removeToolBarIcon(action)
            self.iface.removePluginVectorMenu("&Ferramentas Terra", action)
        self.actions = []
        if self._fullscreen_action is not None and self.toolbar is not None:
            # E a acao nativa do QGIS (View > Tela cheia): so soltamos da
            # nossa barra, nunca a destruimos - ela continua pertencendo ao
            # QGIS e some do menu View normalmente.
            try:
                self.toolbar.removeAction(self._fullscreen_action)
            except Exception:
                pass
            self._fullscreen_action = None
        if self.toolbar is not None:
            del self.toolbar
            self.toolbar = None

    def _add(self, icon_name, text, callback):
        action = QAction(icon(icon_name), text, self.iface.mainWindow())
        action.setToolTip(text)
        action.triggered.connect(callback)
        self.toolbar.addAction(action)
        self.iface.addPluginToVectorMenu("&Ferramentas Terra", action)
        self.actions.append(action)
        return action

    # -------------------------------------------------------------- acoes
    def _track(self, dialog):
        self._dialogs.append(dialog)
        dialog.finished.connect(lambda _: self._untrack(dialog))
        return dialog

    def _untrack(self, dialog):
        if dialog in self._dialogs:
            self._dialogs.remove(dialog)

    def open_feature(self, kind, group=None):
        """Abre a janela de criacao. group = grupo da arvore que recebe a camada."""
        dialog = FeatureDialog(self.iface, kind, group, self.iface.mainWindow())
        self._track(dialog)
        dialog.show()

    def edit_place(self, layer):
        """Abre a janela de edicao daquele lugar (nome, estilo e pontos)."""
        if not storage.is_place_layer(layer):
            QMessageBox.information(
                self.iface.mainWindow(),
                "Ferramentas Terra",
                "Selecione um lugar criado pelo plugin para editar.",
            )
            return
        dialog = EditDialog(self.iface, layer, self.iface.mainWindow())
        self._track(dialog)
        dialog.show()

    def _open_ruler(self):
        dialog = RulerDialog(self.iface, self.iface.mainWindow())
        self._track(dialog)
        dialog.show()

    def _open_goto(self):
        dialog = GotoDialog(self.iface, self.iface.mainWindow())
        self._track(dialog)
        dialog.show()

    def _add_fullscreen_toggle(self):
        """Modo de visualizacao ampliada = reaproveita a tela cheia nativa do
        QGIS (View > Tela cheia), em vez de reimplementar um modo proprio."""
        try:
            action = self.iface.actionToggleFullScreen()
        except Exception:
            action = None
        if action is None:
            return
        self.toolbar.addAction(action)
        self._fullscreen_action = action

    def _new_group(self):
        from qgis.PyQt.QtWidgets import QInputDialog

        name, ok = QInputDialog.getText(
            self.iface.mainWindow(), "Nova pasta", "Nome da pasta:", text="Nova pasta"
        )
        if ok and name.strip():
            QgsProject.instance().layerTreeRoot().insertGroup(0, name.strip())

    def _open_google_maps(self):
        canvas = self.iface.mapCanvas()
        try:
            from . import utils

            wgs = utils.to_wgs84(canvas.center(), canvas.mapSettings().destinationCrs())
        except Exception:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Ferramentas Terra",
                "Nao foi possivel converter o centro do mapa.",
            )
            return
        scale = canvas.scale()
        zoom = 3
        for level in range(1, 22):
            if 591657550.5 / (2 ** (level - 1)) < scale * 2:
                zoom = level
                break
        webbrowser.open(
            "https://www.google.com/maps/@{:.6f},{:.6f},{}z/data=!3m1!1e3".format(
                wgs.y(), wgs.x(), zoom
            )
        )
