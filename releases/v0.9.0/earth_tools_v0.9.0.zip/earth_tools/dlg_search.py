# -*- coding: utf-8 -*-
"""Janela "Pesquisar lugares": filtra por nome e navega até a feição."""

from qgis.core import QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QVBoxLayout,
)

from . import storage, utils

TIPO_LABEL = {"point": "marcador", "line": "caminho", "polygon": "polígono"}


class SearchDialog(QDialog):
    def __init__(self, iface, parent=None):
        super(SearchDialog, self).__init__(parent)
        self.iface = iface

        self.setWindowTitle("Ferramentas Terra - Pesquisar lugares")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setModal(False)
        self.setMinimumSize(360, 420)

        layout = QVBoxLayout(self)
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Digite para filtrar pelo nome...")
        layout.addWidget(self.filter_edit)

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.filter_edit.textChanged.connect(self._refresh_list)
        self.list_widget.itemActivated.connect(self._goto_item)

        self.filter_edit.setFocus()
        self._refresh_list()

    def _all_places(self):
        places = []
        for layer in QgsProject.instance().mapLayers().values():
            if storage.is_place_layer(layer):
                places.append(layer)
        places.sort(key=lambda l: l.name().lower())
        return places

    def _refresh_list(self):
        termo = self.filter_edit.text().strip().lower()
        self.list_widget.clear()
        for layer in self._all_places():
            if termo and termo not in layer.name().lower():
                continue
            kind = layer.customProperty(storage.CUSTOM_KEY) or ""
            rotulo = "{}  ({})".format(layer.name(), TIPO_LABEL.get(kind, kind or "lugar"))
            item = QListWidgetItem(rotulo)
            item.setData(Qt.UserRole, layer.id())
            self.list_widget.addItem(item)

    def _goto_item(self, item):
        layer_id = item.data(Qt.UserRole)
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is not None:
            utils.zoom_to_layer(self.iface, layer)
